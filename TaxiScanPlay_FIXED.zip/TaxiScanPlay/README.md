# TaxiScan — проєкт для Google Play

Android-проєкт TaxiScan з демонстраційним інтерфейсом і початковим екраном підписки:
- Сучасним UI (Material 3)
- Підпискою через **Google Play Billing**
- Правильним package name `ua.taximoney.taxiscan`
- Іконкою TaxiScan та банером на головному екрані
- Gradle Wrapper і GitHub Actions для автоматичної збірки тестового APK

## Швидкий старт

1. Відкрийте папку в **Android Studio** (File → Open)
2. Дочекайтеся синхронізації Gradle
3. Для ручної збірки APK запустіть `gradlew.bat assembleDebug` у Windows або `./gradlew assembleDebug` у Linux/macOS.
4. Створіть підписку в Play Console:
   - Product ID: `taxiscan_premium_monthly`
   - Період: 1 місяць
   - (опційно) Free trial 3–7 днів
5. Для публікації зберіть Android App Bundle (AAB) у Android Studio.

## Структура

```
app/
  src/main/
    java/ua/taximoney/taxiscan/
      MainActivity.kt
      SubscriptionActivity.kt
      PlayBillingManager.kt
    res/
      layout/
        activity_main.xml
        activity_subscription.xml
      values/
        strings.xml, colors.xml, themes.xml
    AndroidManifest.xml
```

## Поточні межі проєкту

- [x] Іконка TaxiScan у всіх стандартних щільностях екрана
- [x] Банер TaxiScan на головному екрані
- [x] Gradle Wrapper та GitHub Actions для debug APK
- [ ] Feature Graphic 1024×500
- [ ] Privacy Policy URL
- [ ] Реальна логіка інтеграції з Uklon / Bolt
- [ ] Перевірка покупок на сервері та збереження Premium-статусу

## Перед публікацією

- Перевірте всі дозволи та заповніть Data safety відповідно до поведінки фінальної програми.
- Якщо додасте Accessibility Service, обґрунтуйте її використання в Play Console.
- Налаштуйте перевірку покупок на сервері перед тим, як надавати доступ до Premium.

Зараз клієнт Billing показує ціну і запускає потік покупки, але застосунок ще не є завершеним сервісом підписки. Головний екран містить заглушки для Uklon, Bolt і групового чату.

## Версія

2.0.0 (versionCode 1)
