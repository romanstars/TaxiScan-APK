# TaxiScan — проєкт для Google Play

Android-проєкт TaxiScan з демонстраційним інтерфейсом і початковим екраном підписки:
- Сучасним UI (Material 3)
- Підпискою через **Google Play Billing**
- Правильним package name `ua.taximoney.taxiscan`
- Іконкою TaxiScan та банером на головному екрані
- Калькулятором чистого доходу за сумою та відстанню
- Запуском встановлених Bolt Driver та Uklon Driver
- Необов'язковим локальним зчитуванням видимого тексту замовлення й сповіщень із передаванням суми/відстані в калькулятор
- Gradle Wrapper і GitHub Actions для автоматичної збірки тестового APK

## Швидкий старт

1. Відкрийте папку в **Android Studio** (File → Open)
2. Дочекайтеся синхронізації Gradle
3. Для ручної збірки APK запустіть `gradlew.bat assembleDebug` у Windows або `./gradlew assembleDebug` у Linux/macOS.
4. Створіть підписку в Play Console:
   - Product ID: `taxiscan_premium_monthly`
   - Період: 1 місяць
   - (опційно) Free trial 3–7 днів
5. Для публікації зберіть Android App Bundle (AAB) у Android Studio.

## Структура

```
app/
  src/main/
    java/ua/taximoney/taxiscan/
      MainActivity.kt
      SubscriptionActivity.kt
      PlayBillingManager.kt
    res/
      layout/
        activity_main.xml
        activity_subscription.xml
      values/
        strings.xml, colors.xml, themes.xml
    AndroidManifest.xml
```

## Поточні межі проєкту

- [x] Іконка TaxiScan у всіх стандартних щільностях екрана
- [x] Банер TaxiScan на головному екрані
- [x] Калькулятор віднімає комісію сервісу та витрати авто на кілометр
- [x] Gradle Wrapper та GitHub Actions для debug APK
- [ ] Feature Graphic 1024×500
- [ ] Privacy Policy URL
- [x] Перший рівень інтеграції: запуск застосунків, зчитування видимого тексту та сповіщень, передавання суми/відстані в калькулятор
- [ ] Перевірка покупок на сервері та збереження Premium-статусу

## Перед публікацією

- Перевірте всі дозволи та заповніть Data safety відповідно до поведінки фінальної програми.
- Accessibility Service активується лише за явною згодою користувача в системних налаштуваннях; вона обробляє видимий текст лише у Bolt Driver/Uklon Driver і не зберігає його. Перед публікацією задекларуйте призначення Accessibility API у Play Console.
- Налаштуйте перевірку покупок на сервері перед тим, як надавати доступ до Premium.

Коли Bolt Driver або Uklon Driver відкрито, TaxiScan читає доступний Android текст екрана й шукає суму з валютою та кілометраж. Значення передаються в калькулятор на цьому телефоні. Точність залежить від того, чи надає поточний екран або сповіщення доступний текст; якщо значення не розпізнано, їх можна ввести вручну. Інтеграцію треба перевірити на реальному телефоні й актуальних версіях обох застосунків.

Клієнт Billing показує ціну і запускає потік покупки, але застосунок ще не є завершеним сервісом підписки.

## Версія

2.1.0 (versionCode 2)
