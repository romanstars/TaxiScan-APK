package ua.taximoney.taxiscan

import android.content.Context
import android.content.SharedPreferences

object DriverPrefs {
    const val FILE = "taxiscan_settings"
    const val MONITORING = "monitoring_enabled"
    const val BOLT = "monitor_bolt"
    const val UKLON = "monitor_uklon"
    const val UBER = "monitor_uber"
    const val FILTER_ENABLED = "filter_enabled"
    const val FILTER_MIN_FARE = "filter_min_fare"
    const val FILTER_MIN_NET_KM = "filter_min_net_per_km"
    const val FILTER_MAX_DISTANCE = "filter_max_distance"
    const val SOUND_ENABLED = "sound_enabled"
    const val SOUND_STREAM = "sound_stream"
    const val OVERLAY_MODE = "overlay_mode"
    const val OVERLAY_COLOR = "overlay_color"
    const val OVERLAY_ALPHA = "overlay_alpha"
    const val OVERLAY_TEXT_SIZE = "overlay_text_size"
    const val AUTO_LAUNCH_BOLT = "auto_launch_bolt"
    const val AUTO_ACCEPT_SCHEDULED = "auto_accept_scheduled"
    const val LOGS_PAUSED = "logs_paused"
    const val LOG_LINES = "order_log_lines"
    const val AUTO_CLICK_ENABLED = "auto_click_enabled"
    const val AUTO_CLICK_TEXT = "auto_click_text"
    const val AUTO_CLICK_LAST_TIME = "auto_click_last_time"
    const val AI_ENDPOINT = "ai_endpoint"
    const val AI_API_KEY = "ai_api_key"
    const val TIMER_ACCEPTED = "timer_accepted_min"
    const val TIMER_MEETING = "timer_meeting_min"
    const val TIMER_IDLE = "timer_idle_min"
    const val TIMER_WAIT = "timer_wait_min"
    const val TIMER_GENERAL = "timer_general_min"

    fun prefs(context: Context): SharedPreferences = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isMonitoringAllowed(context: Context, service: String): Boolean {
        val prefs = prefs(context)
        if (!prefs.getBoolean(MONITORING, true)) return false
        return when (service) {
            "Bolt" -> prefs.getBoolean(BOLT, true)
            "Uklon" -> prefs.getBoolean(UKLON, true)
            "Uber" -> prefs.getBoolean(UBER, true)
            else -> false
        }
    }

    fun orderPassesFilter(context: Context, fare: Double, distance: Double): Boolean {
        val prefs = prefs(context)
        if (!prefs.getBoolean(FILTER_ENABLED, false)) return true
        if (distance <= 0.0 || fare < prefs.getFloat(FILTER_MIN_FARE, 0f)) return false
        if (distance > prefs.getFloat(FILTER_MAX_DISTANCE, 50f)) return false
        val commission = prefs.getFloat("commission_percent", 15f).toDouble()
        val cost = prefs.getFloat("cost_per_km", 9f).toDouble()
        val netPerKm = (fare - fare * commission / 100.0 - distance * cost) / distance
        return netPerKm >= prefs.getFloat(FILTER_MIN_NET_KM, 0f)
    }
}
