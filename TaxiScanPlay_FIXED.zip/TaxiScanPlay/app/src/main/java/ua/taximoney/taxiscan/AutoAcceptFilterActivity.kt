package ua.taximoney.taxiscan

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject

class AutoAcceptFilterActivity : AppCompatActivity() {
    private val prefs by lazy { DriverPrefs.prefs(this) }
    private lateinit var autoSwitch: Switch
    private lateinit var fare: EditText
    private lateinit var pickup: EditText
    private lateinit var perKm: EditText
    private lateinit var hourly: EditText
    private lateinit var rating: EditText
    private lateinit var required: EditText
    private lateinit var excluded: EditText
    private lateinit var rejectOutside: CheckBox
    private lateinit var lastValues: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Фільтр автоприйняття"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(16))
            setBackgroundColor(Color.rgb(16, 19, 19))
        }
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.rgb(27, 29, 29), Color.rgb(0, 213, 230), 3)
        }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        frame.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val toggleBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(21, 91, 34), Color.rgb(75, 184, 87), 2)
        }
        toggleBox.addView(TextView(this).apply {
            text = "Викл/Вкл  ➡  АВТОПРИЙОМ"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(186, 224, 190))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        autoSwitch = Switch(this).apply { isChecked = prefs.getBoolean(DriverPrefs.AUTO_ACCEPT_ENABLED, false) }
        toggleBox.addView(autoSwitch)
        content.addView(toggleBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        content.addView(TextView(this).apply {
            text = "Автодії: ${prefs.getInt(DriverPrefs.AUTO_ACTIONS_COUNT, 0)}  •  сервісів: Bolt / Uklon / Uber"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(2), dp(4), dp(12))
        })
        lastValues = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(180, 198, 190))
            setPadding(dp(4), 0, dp(4), dp(8))
        }
        content.addView(lastValues)
        content.addView(columnsHeader())
        fare = numberField(prefs.getFloat(DriverPrefs.AUTO_FILTER_MIN_FARE, 150f), "150")
        pickup = numberField(prefs.getFloat(DriverPrefs.FILTER_MAX_PICKUP, 2f), "2")
        perKm = numberField(prefs.getFloat(DriverPrefs.AUTO_FILTER_MIN_PER_KM, 30f), "30")
        hourly = numberField(prefs.getFloat(DriverPrefs.FILTER_MIN_HOURLY, 300f), "300")
        rating = numberField(prefs.getFloat(DriverPrefs.FILTER_MIN_RATING, 0f), "Не задано")
        content.addView(parameterRow("Мін-заробіток, ₴", last(DriverPrefs.LAST_OFFER_FARE), fare))
        content.addView(parameterRow("Макс. подача, км", last(DriverPrefs.LAST_OFFER_PICKUP), pickup))
        content.addView(parameterRow("Мін. ₴/км", last(DriverPrefs.LAST_OFFER_DISTANCE), perKm))
        content.addView(parameterRow("Мін. заробіток/год, ₴", last(DriverPrefs.LAST_OFFER_HOURLY), hourly))
        content.addView(parameterRow("Мін. рейтинг", last(DriverPrefs.LAST_OFFER_RATING), rating))

        required = addressField(prefs.getString(DriverPrefs.FILTER_REQUIRED_ADDRESSES, "").orEmpty(), "Введіть райони або адреси через кому")
        excluded = addressField(prefs.getString(DriverPrefs.FILTER_EXCLUDED_ADDRESSES, "").orEmpty(), "Адреси для виключення через кому")
        content.addView(addressRow("Потрібні адреси", "Підходить", required))
        content.addView(addressRow("Небажані адреси", "Пусто", excluded))

        val mode = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        mode.addView(TextView(this).apply {
            text = "Режим роботи:"
            setTextColor(Color.rgb(167, 219, 177))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        mode.addView(TextView(this).apply {
            text = "Приймати відповідні замовлення"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        })
        content.addView(mode)

        rejectOutside = CheckBox(this).apply {
            text = "Відхиляти замовлення поза радіусом подачі"
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 193, 7))
            isChecked = prefs.getBoolean(DriverPrefs.AUTO_REJECT_OUTSIDE_RADIUS, false)
        }
        content.addView(rejectOutside)

        val templateButton = actionButton("🗂  ВИБРАТИ ШАБЛОН", Color.rgb(0, 188, 220)) { chooseTemplate() }
        content.addView(templateButton, buttonParams())
        val saveTemplateButton = actionButton("ЗБЕРЕГТИ ПОТОЧНИЙ ШАБЛОН", Color.rgb(0, 126, 152)) { saveTemplate() }
        content.addView(saveTemplateButton, buttonParams())
        val wheelButton = actionButton("⚙  Налаштування кроку колеса прокрутки", Color.rgb(0, 83, 92)) { wheelSettings() }
        content.addView(wheelButton, buttonParams())

        val warning = TextView(this).apply {
            text = "Автоприйняття може підтвердити поїздку у сторонньому сервісі. Воно працює лише після ввімкнення та якщо TaxiScan розпізнав потрібні параметри й кнопку. Перевірте правила Bolt, Uklon та Uber."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(6), dp(10), dp(6), dp(8))
        }
        content.addView(warning)

        val save = actionButton("✅  ЗБЕРЕГТИ ТА ЗАКРИТИ", Color.rgb(0, 203, 111)) { saveAndClose() }
        root.addView(save, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(10) })
        setContentView(root)
        refreshLastValues()
    }

    override fun onResume() {
        super.onResume()
        if (::lastValues.isInitialized) refreshLastValues()
    }

    private fun columnsHeader(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(label("Параметр", Color.LTGRAY), LinearLayout.LayoutParams(0, -2, 1.3f))
        addView(label("Останнє", Color.rgb(255, 193, 7)), LinearLayout.LayoutParams(0, -2, .8f))
        addView(label("Фільтр", Color.rgb(0, 215, 230)), LinearLayout.LayoutParams(0, -2, .8f))
    }

    private fun parameterRow(title: String, last: String, input: EditText): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(3), 0, dp(3))
        addView(label(title, Color.WHITE), LinearLayout.LayoutParams(0, dp(48), 1.3f))
        val current = label(last, Color.LTGRAY).apply { gravity = Gravity.CENTER; setBackgroundColor(Color.rgb(46, 61, 66)) }
        addView(current, LinearLayout.LayoutParams(0, dp(48), .8f).apply { marginEnd = dp(3) })
        input.gravity = Gravity.CENTER
        input.setTextColor(Color.rgb(0, 221, 238))
        input.background = rounded(Color.rgb(39, 54, 60), Color.rgb(0, 208, 229), 2)
        input.setOnLongClickListener { showWheelPicker(input, title); true }
        addView(input, LinearLayout.LayoutParams(0, dp(48), .8f))
    }

    private fun addressRow(title: String, current: String, input: EditText) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(4), dp(4), dp(4), dp(6))
        addView(TextView(this@AutoAcceptFilterActivity).apply {
            text = "$title  •  $current"
            textSize = 14f
            setTextColor(Color.rgb(0, 215, 230))
            setTypeface(typeface, Typeface.BOLD)
        })
        addView(input, LinearLayout.LayoutParams(-1, dp(48)))
    }

    private fun numberField(value: Float, hintText: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setText(if (value == 0f && hintText == "Не задано") "" else value.toString())
        hint = hintText
        setSingleLine(true)
        setPadding(dp(4), 0, dp(4), 0)
    }

    private fun addressField(value: String, hintText: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        setText(value)
        hint = hintText
        setSingleLine(true)
        setPadding(dp(10), 0, dp(10), 0)
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(39, 54, 60), Color.rgb(0, 208, 229), 1)
    }

    private fun label(textValue: String, color: Int) = TextView(this).apply {
        text = textValue
        textSize = 13f
        setTextColor(color)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(3), 0, dp(3), 0)
    }

    private fun last(key: String): String = prefs.getString(key, "—") ?: "—"

    private fun refreshLastValues() {
        val amount = last(DriverPrefs.LAST_OFFER_FARE)
        val pickupDistance = last(DriverPrefs.LAST_OFFER_PICKUP)
        val perKmValue = last(DriverPrefs.LAST_OFFER_DISTANCE)
        val perHourValue = last(DriverPrefs.LAST_OFFER_HOURLY)
        val ratingValue = last(DriverPrefs.LAST_OFFER_RATING)
        lastValues.text = "Остання пропозиція: $amount ₴ • подача $pickupDistance км • $perKmValue ₴/км • $perHourValue ₴/год • рейтинг $ratingValue"
    }

    private fun actionButton(textValue: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = textValue
        textSize = 15f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(color, color, 2)
        setOnClickListener { action() }
    }

    private fun buttonParams() = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(7) }

    private fun chooseTemplate() {
        val templates = arrayOf("Збалансований", "Економний", "Високий дохід", "Мій шаблон")
        MaterialAlertDialogBuilder(this).setTitle("Вибрати шаблон").setItems(templates) { _, index ->
            when (index) {
                0 -> applyValues(150f, 2f, 30f, 300f, 0f)
                1 -> applyValues(100f, 4f, 20f, 240f, 0f)
                2 -> applyValues(220f, 1.5f, 40f, 360f, 0f)
                3 -> loadTemplate()
            }
        }.show()
    }

    private fun saveTemplate() {
        val obj = JSONObject().put("fare", value(fare, 150f)).put("pickup", value(pickup, 2f))
            .put("perKm", value(perKm, 30f)).put("hourly", value(hourly, 300f)).put("rating", value(rating, 0f))
            .put("required", required.text.toString()).put("excluded", excluded.text.toString())
        prefs.edit().putString(DriverPrefs.FILTER_TEMPLATE, obj.toString()).apply()
        toast("Шаблон збережено")
    }

    private fun loadTemplate() {
        val raw = prefs.getString(DriverPrefs.FILTER_TEMPLATE, null) ?: return toast("Спочатку збережіть свій шаблон")
        runCatching {
            val obj = JSONObject(raw)
            applyValues(obj.optDouble("fare", 150.0).toFloat(), obj.optDouble("pickup", 2.0).toFloat(),
                obj.optDouble("perKm", 30.0).toFloat(), obj.optDouble("hourly", 300.0).toFloat(), obj.optDouble("rating", 0.0).toFloat())
            required.setText(obj.optString("required"))
            excluded.setText(obj.optString("excluded"))
        }.onFailure { toast("Не вдалося завантажити шаблон") }
    }

    private fun applyValues(minFare: Float, maxPickup: Float, minPerKm: Float, minHourly: Float, minRating: Float) {
        fare.setText(minFare.toString())
        pickup.setText(maxPickup.toString())
        perKm.setText(minPerKm.toString())
        hourly.setText(minHourly.toString())
        rating.setText(if (minRating <= 0f) "" else minRating.toString())
    }

    private fun wheelSettings() {
        val picker = NumberPicker(this).apply {
            minValue = 1
            maxValue = 10
            value = prefs.getInt(DriverPrefs.FILTER_SCROLL_STEP, 1).coerceIn(1, 10)
        }
        MaterialAlertDialogBuilder(this).setTitle("Крок колеса прокрутки").setMessage("Затисніть поле фільтра, щоб змінити число коліщатком із цим кроком.")
            .setView(picker).setNegativeButton("Скасувати", null)
            .setPositiveButton("Зберегти") { _, _ -> prefs.edit().putInt(DriverPrefs.FILTER_SCROLL_STEP, picker.value).apply() }.show()
    }

    private fun showWheelPicker(field: EditText, title: String) {
        val smallStep = title.contains("подач", true) || title.contains("рейтинг", true)
        val stepSetting = prefs.getInt(DriverPrefs.FILTER_SCROLL_STEP, 1).coerceIn(1, 10)
        val step = if (smallStep) stepSetting / 10f else stepSetting.toFloat()
        val maxValue = if (title.contains("рейтинг", true)) 5f else if (title.contains("подач", true)) 50f else 3000f
        val count = (maxValue / step).toInt().coerceIn(1, 3000)
        val choices = (0..count).map { index ->
            val number = index * step
            if (smallStep) String.format(java.util.Locale.US, "%.1f", number) else number.toInt().toString()
        }.toTypedArray()
        val wheel = NumberPicker(this).apply {
            minValue = 0
            this.maxValue = count
            displayedValues = choices
            wrapSelectorWheel = false
            value = ((field.text.toString().replace(',', '.').toFloatOrNull() ?: 0f) / step).toInt().coerceIn(0, count)
        }
        MaterialAlertDialogBuilder(this).setTitle(title).setView(wheel)
            .setNegativeButton("Скасувати", null)
            .setPositiveButton("Застосувати") { _, _ -> field.setText(choices[wheel.value]) }
            .show()
    }

    private fun saveAndClose() {
        val enable = autoSwitch.isChecked
        if (enable && !prefs.getBoolean(DriverPrefs.AUTO_ACCEPT_ENABLED, false)) {
            MaterialAlertDialogBuilder(this).setTitle("Увімкнути автоприйняття?")
                .setMessage("TaxiScan натискатиме кнопку прийняття в Bolt, Uklon або Uber, якщо всі задані умови пройдені. Це може підтвердити поїздку та створити зобов’язання. Продовжити?")
                .setNegativeButton("Повернутися до фільтра", null)
                .setPositiveButton("Увімкнути") { _, _ -> persist(true); finish() }.show()
        } else {
            persist(enable)
            finish()
        }
    }

    private fun persist(enable: Boolean) {
        prefs.edit()
            .putBoolean(DriverPrefs.AUTO_ACCEPT_ENABLED, enable)
            .putBoolean(DriverPrefs.AUTO_REJECT_OUTSIDE_RADIUS, rejectOutside.isChecked)
            .putFloat(DriverPrefs.AUTO_FILTER_MIN_FARE, value(fare, 150f))
            .putFloat(DriverPrefs.FILTER_MAX_PICKUP, value(pickup, 2f))
            .putFloat(DriverPrefs.AUTO_FILTER_MIN_PER_KM, value(perKm, 30f))
            .putFloat(DriverPrefs.FILTER_MIN_HOURLY, value(hourly, 300f))
            .putFloat(DriverPrefs.FILTER_MIN_RATING, value(rating, 0f).coerceIn(0f, 5f))
            .putString(DriverPrefs.FILTER_REQUIRED_ADDRESSES, required.text.toString())
            .putString(DriverPrefs.FILTER_EXCLUDED_ADDRESSES, excluded.text.toString())
            .apply()
    }

    private fun value(field: EditText, fallback: Float): Float = field.text.toString().replace(',', '.').toFloatOrNull() ?: fallback
    private fun rounded(fill: Int, stroke: Int, width: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(12).toFloat()
        setStroke(dp(width), stroke)
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
