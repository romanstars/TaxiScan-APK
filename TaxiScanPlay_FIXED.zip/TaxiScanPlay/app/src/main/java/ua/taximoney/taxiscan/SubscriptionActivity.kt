package ua.taximoney.taxiscan

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

class SubscriptionActivity : AppCompatActivity() {

    private lateinit var billingManager: PlayBillingManager
    private lateinit var tvStatusTitle: TextView
    private lateinit var tvStatusSub: TextView
    private lateinit var tvPrice: TextView
    private lateinit var tvOfferDetails: TextView
    private lateinit var btnSubscribe: MaterialButton
    private lateinit var tvManage: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_subscription)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        tvStatusTitle = findViewById(R.id.tvStatusTitle)
        tvStatusSub = findViewById(R.id.tvStatusSub)
        tvPrice = findViewById(R.id.tvPrice)
        tvOfferDetails = findViewById(R.id.tvOfferDetails)
        btnSubscribe = findViewById(R.id.btnSubscribe)
        tvManage = findViewById(R.id.tvManage)

        billingManager = PlayBillingManager(this) { isActive ->
            runOnUiThread { updateUI(isActive) }
        }
        billingManager.startConnection()

        btnSubscribe.setOnClickListener {
            billingManager.launchPurchase(this)
        }

        tvManage.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://play.google.com/store/account/subscriptions"
            )))
        }
    }

    private fun updateUI(isActive: Boolean) {
        if (isActive) {
            tvStatusTitle.text = getString(R.string.subscription_active)
            tvStatusTitle.setTextColor(Color.parseColor("#32BB78"))
            tvStatusSub.text = "Підписка діє"
            btnSubscribe.text = getString(R.string.manage_subscription)
            tvManage.visibility = View.VISIBLE
        } else {
            tvStatusTitle.text = getString(R.string.subscription_inactive)
            tvStatusTitle.setTextColor(Color.parseColor("#F44336"))
            tvPrice.text = billingManager.getPrice()
            tvOfferDetails.text = billingManager.getOfferDetails()
            btnSubscribe.text = if (billingManager.hasFreeTrial())
                "Почати безкоштовний період"
            else
                getString(R.string.subscribe)
            tvManage.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        billingManager.endConnection()
    }
}
