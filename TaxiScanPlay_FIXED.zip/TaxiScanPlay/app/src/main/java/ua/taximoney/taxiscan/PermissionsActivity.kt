package ua.taximoney.taxiscan

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.text.NumberFormat
import java.util.Locale

class PermissionsActivity : AppCompatActivity() {
    private lateinit var permissionHeader: TextView
    private lateinit var permissionsGroup: LinearLayout
    private lateinit var boltStats: TextView
    private lateinit var uklonStats: TextView
    private val rows = mutableListOf<PermissionRow>()
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshRows()
    }
    private val locationPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshRows()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.permissions_title)
        buildScreen()
        buildPermissionRows()
    }

    override fun onResume() {
        super.onResume()
        refreshRows()
        refreshStats()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
            setBackgroundColor(Color.rgb(13, 15, 14))
        }
        val scrollView = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        boltStats = addStatsCard(stats, R.string.bolt_stats, "Bolt")
        uklonStats = addStatsCard(stats, R.string.uklon_stats, "Uklon")
        content.addView(stats)

        permissionHeader = TextView(this).apply {
            text = "${getString(R.string.permissions_title)}                         ▴"
            setTextColor(Color.rgb(210, 216, 212))
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(16), dp(8), dp(10))
            isClickable = true
            isFocusable = true
        }
        permissionsGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        permissionHeader.setOnClickListener {
            permissionsGroup.visibility = if (permissionsGroup.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            permissionHeader.text = "${getString(R.string.permissions_title)}                         " +
                if (permissionsGroup.visibility == View.VISIBLE) "▴" else "▾"
        }
        content.addView(permissionHeader)
        content.addView(permissionsGroup)

        scrollView.addView(content)
        root.addView(scrollView)
        setContentView(root)
    }

    private fun addStatsCard(parent: LinearLayout, titleId: Int, service: String): TextView {
        val card = MaterialCardView(this).apply {
            radius = dp(20).toFloat()
            cardElevation = 0f
            setCardBackgroundColor(if (service == "Bolt") Color.rgb(16, 48, 34) else Color.rgb(255, 211, 0))
            strokeWidth = dp(1)
            strokeColor = if (service == "Bolt") Color.rgb(66, 150, 100) else Color.rgb(225, 182, 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(112), 1f).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            }
        }
        val text = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setTextColor(if (service == "Bolt") Color.WHITE else Color.BLACK)
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            text = getString(titleId)
        }
        card.addView(text)
        parent.addView(card)
        return text
    }

    private fun buildPermissionRows() {
        rows.clear()
        rows += row(R.string.perm_keep_awake, R.string.perm_disable) { openAppDetails() }
        rows += row(R.string.perm_accessibility) { startSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        rows += row(R.string.perm_battery, R.string.perm_battery_button) { openBatterySettings() }
        rows += row(R.string.perm_overlay) { openOverlaySettings() }
        rows += row(R.string.perm_notifications) { requestNotificationPermission() }
        rows += row(R.string.perm_location) { requestLocationPermission() }
        rows += row(R.string.perm_notification_access) { openNotificationAccessSettings() }
        rows += row(R.string.perm_autostart, R.string.perm_autostart_button) { openAutostartSettings() }
        rows += row(R.string.perm_app_settings, R.string.perm_open) { openAppDetails() }
        rows.forEach { permissionsGroup.addView(it.card) }
    }

    private fun row(labelId: Int, buttonLabelId: Int? = null, action: () -> Unit): PermissionRow {
        val card = MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = 0f
            setCardBackgroundColor(Color.rgb(18, 43, 29))
            strokeWidth = dp(2)
            strokeColor = Color.rgb(78, 174, 91)
            layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(5)
                bottomMargin = dp(5)
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(8), dp(8), dp(8))
        }
        val number = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 21f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(74, 176, 88))
            }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        val label = TextView(this).apply {
            text = getString(labelId)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(93, 190, 104))
            setPadding(dp(10), 0, dp(6), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val button = MaterialButton(this).apply {
            textSize = 13f
            isAllCaps = false
            setTextColor(Color.rgb(25, 27, 26))
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(222, 224, 223))
            cornerRadius = dp(7)
            insetTop = 0
            insetBottom = 0
            minWidth = dp(86)
            minimumHeight = dp(46)
            text = getString(buttonLabelId ?: R.string.perm_allow)
            setOnClickListener { action() }
        }
        row.addView(number)
        row.addView(label)
        row.addView(button)
        card.addView(row)
        return PermissionRow(labelId, card, number, label, button, buttonLabelId ?: R.string.perm_allow, action)
    }

    private fun refreshRows() {
        if (rows.isEmpty()) return
        rows.forEachIndexed { index, row ->
            row.number.text = (index + 1).toString()
            val granted: Boolean? = when (row.labelId) {
                R.string.perm_accessibility -> isAccessibilityEnabled()
                R.string.perm_battery -> (getSystemService(POWER_SERVICE) as PowerManager)
                    .isIgnoringBatteryOptimizations(packageName)
                R.string.perm_overlay -> Settings.canDrawOverlays(this)
                R.string.perm_notifications -> Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.POST_NOTIFICATIONS)
                R.string.perm_location -> hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
                    hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                R.string.perm_notification_access -> isNotificationAccessEnabled()
                else -> null
            }
            row.button.text = when {
                row.labelId == R.string.perm_keep_awake -> getString(R.string.perm_disable)
                row.labelId == R.string.perm_battery -> getString(R.string.perm_battery_button)
                row.labelId == R.string.perm_autostart -> getString(R.string.perm_autostart_button)
                row.labelId == R.string.perm_app_settings -> getString(R.string.perm_open)
                granted == true -> getString(R.string.perm_enabled)
                else -> getString(R.string.perm_allow)
            }
            val (background, accent) = when (granted) {
                true -> Color.rgb(20, 72, 42) to Color.rgb(76, 190, 96)
                false -> Color.rgb(75, 29, 31) to Color.rgb(244, 86, 82)
                null -> Color.rgb(20, 43, 60) to Color.rgb(48, 177, 230)
            }
            row.card.setCardBackgroundColor(background)
            row.card.strokeColor = accent
            row.label.setTextColor(accent)
            row.number.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accent)
            }
            row.button.backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
            row.button.setTextColor(Color.WHITE)
        }
    }

    private fun refreshStats() {
        val numberFormat = NumberFormat.getNumberInstance(Locale.forLanguageTag("uk-UA")).apply {
            minimumFractionDigits = 0
            maximumFractionDigits = 2
        }
        val bolt = RideCapture.stats(this, "Bolt")
        val uklon = RideCapture.stats(this, "Uklon")
        boltStats.text = "Bolt\n${getString(R.string.trips_summary, "${numberFormat.format(bolt.first)} ₴", bolt.second)}"
        uklonStats.text = "Uklon\n${getString(R.string.trips_summary, "${numberFormat.format(uklon.first)} ₴", uklon.second)}"
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startSystemSettings(Settings.ACTION_APP_NOTIFICATION_SETTINGS, Settings.EXTRA_APP_PACKAGE, packageName)
        }
    }

    private fun requestLocationPermission() {
        val missing = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            .filterNot(::hasPermission)
        if (missing.isNotEmpty()) locationPermissions.launch(missing.toTypedArray())
        else startSystemSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, data = Uri.parse("package:$packageName"))
    }

    private fun openBatterySettings() {
        val intent = if ((getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)) {
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        } else {
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        }
        launchSafely(intent)
    }

    private fun openOverlaySettings() = startSystemSettings(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        data = Uri.parse("package:$packageName")
    )

    private fun openNotificationAccessSettings() = startSystemSettings("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")

    private fun openAutostartSettings() {
        val miui = Intent("miui.intent.action.OP_AUTO_START").setPackage("com.miui.securitycenter")
        if (miui.resolveActivity(packageManager) != null) launchSafely(miui) else openAppDetails()
    }

    private fun openAppDetails() = startSystemSettings(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        data = Uri.parse("package:$packageName")
    )

    private fun startSystemSettings(action: String, extraKey: String? = null, extraValue: String? = null, data: Uri? = null) {
        val intent = Intent(action).apply {
            if (extraKey != null && extraValue != null) putExtra(extraKey, extraValue)
            if (data != null) this.data = data
        }
        launchSafely(intent)
    }

    private fun launchSafely(intent: Intent) {
        runCatching { startActivity(intent) }.onFailure {
            if (intent.action != Settings.ACTION_SETTINGS) {
                runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val component = ComponentName(this, RideAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        val component = ComponentName(this, RideNotificationListener::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private data class PermissionRow(
        val labelId: Int,
        val card: MaterialCardView,
        val number: TextView,
        val label: TextView,
        val button: MaterialButton,
        val defaultButtonLabel: Int,
        val action: () -> Unit
    )
}
