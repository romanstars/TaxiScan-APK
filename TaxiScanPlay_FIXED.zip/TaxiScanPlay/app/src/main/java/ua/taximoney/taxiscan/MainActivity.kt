package ua.taximoney.taxiscan

import android.content.Intent
import android.content.ComponentName
import android.provider.Settings
import android.net.Uri
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings.Secure
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONArray
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvSubTitle: TextView
    private lateinit var tvSubStatus: TextView
    private lateinit var tvPriceValue: TextView
    private lateinit var tvCommissionValue: TextView
    private lateinit var etTripAmount: EditText
    private lateinit var etTripDistance: EditText
    private lateinit var layoutCalcResult: View
    private lateinit var tvNetResult: TextView
    private lateinit var tvOrderBreakdown: TextView
    private lateinit var tvPerKm: TextView
    private lateinit var tvNotificationAccessStatus: TextView
    private lateinit var tvUklonStatus: TextView
    private lateinit var tvBoltStatus: TextView
    private lateinit var tvUberStatus: TextView
    private lateinit var tvOverlayAccess: TextView
    private lateinit var tvScreenAccessStatus: TextView
    private lateinit var tvNotificationStatus: TextView
    private lateinit var tvPermissionsProgress: TextView
    private lateinit var tvPermissionsTitle: TextView
    private lateinit var progressPermissions: ProgressBar
    private lateinit var tvRadarTitle: TextView
    private lateinit var tvRadarBadge: TextView
    private lateinit var tvRadarSwitchLabel: TextView
    private lateinit var switchRadar: SwitchMaterial
    private lateinit var tvTodayRevenue: TextView
    private lateinit var tvTodayTrips: TextView
    private lateinit var tvHourlyRevenue: TextView
    private lateinit var homeScroll: NestedScrollView
    private lateinit var statsScroll: NestedScrollView
    private lateinit var settingsScroll: NestedScrollView
    private var statsPeriod = R.id.btnStatsDay
    private var isSubscribed = false
    private val preferences by lazy { getSharedPreferences("taxiscan_settings", MODE_PRIVATE) }
    private val numberFormat by lazy {
        NumberFormat.getNumberInstance(Locale.forLanguageTag("uk-UA")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
    }
    private val orderReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action != RideCapture.ACTION_ORDER_CAPTURED) return
            applyCapturedOrder(
                intent.getStringExtra(RideCapture.EXTRA_SERVICE).orEmpty(),
                intent.getDoubleExtra(RideCapture.EXTRA_FARE, -1.0).takeIf { it > 0 },
                intent.getDoubleExtra(RideCapture.EXTRA_DISTANCE, -1.0).takeIf { it > 0 }
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val themeMode = getSharedPreferences("taxiscan_settings", MODE_PRIVATE).getInt(KEY_THEME_MODE, 0)
        AppCompatDelegate.setDefaultNightMode(
            when (themeMode) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                else -> AppCompatDelegate.MODE_NIGHT_YES
            }
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSubTitle = findViewById(R.id.tvSubTitle)
        tvSubStatus = findViewById(R.id.tvSubStatus)
        tvPriceValue = findViewById(R.id.tvPriceValue)
        tvCommissionValue = findViewById(R.id.tvCommissionValue)
        etTripAmount = findViewById(R.id.etTripAmount)
        etTripDistance = findViewById(R.id.etTripDistance)
        layoutCalcResult = findViewById(R.id.layoutCalcResult)
        tvNetResult = findViewById(R.id.tvNetResult)
        tvOrderBreakdown = findViewById(R.id.tvOrderBreakdown)
        tvPerKm = findViewById(R.id.tvPerKm)
        tvNotificationAccessStatus = findViewById(R.id.tvNotificationAccessStatus)
        tvUklonStatus = findViewById(R.id.tvUklonStatus)
        tvBoltStatus = findViewById(R.id.tvBoltStatus)
        tvUberStatus = findViewById(R.id.tvUberStatus)
        tvOverlayAccess = findViewById(R.id.btnOverlayAccess)
        tvScreenAccessStatus = findViewById(R.id.tvScreenAccessStatus)
        tvNotificationStatus = findViewById(R.id.tvNotificationStatus)
        tvPermissionsProgress = findViewById(R.id.tvPermissionsProgress)
        tvPermissionsTitle = findViewById(R.id.tvPermissionsTitle)
        progressPermissions = findViewById(R.id.progressPermissions)
        tvRadarTitle = findViewById(R.id.tvRadarTitle)
        tvRadarBadge = findViewById(R.id.tvRadarBadge)
        tvRadarSwitchLabel = findViewById(R.id.tvRadarSwitchLabel)
        switchRadar = findViewById(R.id.switchRadar)
        tvTodayRevenue = findViewById(R.id.tvTodayRevenue)
        tvTodayTrips = findViewById(R.id.tvTodayTrips)
        tvHourlyRevenue = findViewById(R.id.tvHourlyRevenue)
        homeScroll = findViewById(R.id.homeScroll)
        statsScroll = findViewById(R.id.statsScroll)
        settingsScroll = findViewById(R.id.settingsScroll)
        val brand = SpannableString("TaxiScan")
        brand.setSpan(ForegroundColorSpan(Color.parseColor("#FFD600")), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        brand.setSpan(ForegroundColorSpan(Color.parseColor("#32D98A")), 4, brand.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        findViewById<TextView>(R.id.tvBrand).text = brand
        findViewById<TextView>(R.id.tvBrandStats).text = SpannableString(brand)
        findViewById<TextView>(R.id.tvBrandSettings).text = SpannableString(brand)
        updateSettingsLabels()

        statsPeriod = preferences.getInt(KEY_STATS_PERIOD, R.id.btnStatsDay)
        findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.statsPeriodGroup).apply {
            check(statsPeriod)
            addOnButtonCheckedListener { _, checkedId, isChecked ->
                if (isChecked) {
                    statsPeriod = checkedId
                    preferences.edit().putInt(KEY_STATS_PERIOD, checkedId).apply()
                    renderStatistics()
                }
            }
        }
        setupSettingsScreen()
        renderStatistics()

        switchRadar.setOnCheckedChangeListener { _, checked ->
            val p = DriverPrefs.prefs(this)
            val serviceKeys = listOf(DriverPrefs.BOLT, DriverPrefs.UKLON, DriverPrefs.UBER)
            if (checked && serviceKeys.none { p.getBoolean(it, true) }) {
                p.edit().putBoolean(DriverPrefs.BOLT, true).putBoolean(DriverPrefs.UKLON, true)
                    .putBoolean(DriverPrefs.UBER, true).apply()
            }
            p.edit().putBoolean(DriverPrefs.MONITORING, checked).apply()
            updateRadarState()
        }

        findViewById<MaterialButton>(R.id.btnCalculate).setOnClickListener {
            calculateTrip()
        }

        findViewById<View>(R.id.itemPrice).setOnClickListener {
            showNumberSettingDialog(
                title = getString(R.string.car_cost_dialog_title),
                preferenceKey = KEY_COST_PER_KM,
                currentValue = costPerKm,
                minimum = 0.0,
                maximum = 100_000.0
            )
        }

        findViewById<View>(R.id.itemCommission).setOnClickListener {
            showNumberSettingDialog(
                title = getString(R.string.commission_dialog_title),
                preferenceKey = KEY_COMMISSION,
                currentValue = commissionPercent,
                minimum = 0.0,
                maximum = 100.0
            )
        }

        findViewById<View>(R.id.settingCarCost).setOnClickListener { openCarCostSetting() }
        findViewById<View>(R.id.settingCommission).setOnClickListener { openCommissionSetting() }
        findViewById<View>(R.id.settingIdleRate).setOnClickListener {
            showNumberSettingDialog(
                title = "Тариф за простій (₴/год)",
                preferenceKey = KEY_IDLE_RATE,
                currentValue = preferences.getFloat(KEY_IDLE_RATE, 0f).toDouble(),
                minimum = 0.0,
                maximum = 100_000.0
            )
        }

        findViewById<MaterialCardView>(R.id.cardSubscription).setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardUklon).setOnClickListener {
            openServiceApp("Uklon", "ua.com.uklon.uklondriver")
        }

        findViewById<MaterialCardView>(R.id.cardBolt).setOnClickListener {
            openServiceApp("Bolt", "ee.mtakso.driver")
        }
        findViewById<MaterialCardView>(R.id.cardUber).setOnClickListener {
            openServiceApp("Uber", "com.ubercab.driver")
        }

        findViewById<MaterialButton>(R.id.btnNotificationAccess).setOnClickListener {
            showAccessChoices()
        }
        tvOverlayAccess.setOnClickListener { showOverlayDisclosure() }
        findViewById<MaterialButton>(R.id.btnSystemPermissions).setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        findViewById<View>(R.id.btnDriverTools).setOnClickListener {
            startActivity(Intent(this, DriverToolsActivity::class.java))
        }

        if (savedInstanceState == null && preferences.getBoolean(DriverPrefs.AUTO_LAUNCH_BOLT, false)) {
            openServiceApp("Bolt", "ee.mtakso.driver")
        }

        findViewById<TextView>(R.id.tvJoinGroup).setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        findViewById<View>(R.id.navHome).setOnClickListener { selectBottomTab(R.id.navHome); homeScroll.smoothScrollTo(0, 0) }
        findViewById<View>(R.id.navCalculator).setOnClickListener {
            selectBottomTab(R.id.navCalculator)
            val calculator = findViewById<View>(R.id.cardCalculator)
            val location = IntArray(2)
            calculator.getLocationInWindow(location)
            homeScroll.smoothScrollTo(0, homeScroll.scrollY + location[1] - homeScroll.top)
            etTripAmount.requestFocus()
        }
        findViewById<View>(R.id.navStatistics).setOnClickListener { selectBottomTab(R.id.navStatistics); renderStatistics() }
        findViewById<View>(R.id.navSettings).setOnClickListener { selectBottomTab(R.id.navSettings); refreshSettingsScreen() }
    }

    override fun onResume() {
        super.onResume()
        updateSubscriptionCard()
        updateIntegrationStatus()
        updateDailyStats()
        updateSettingsLabels()
        refreshSettingsScreen()
        if (statsScroll.visibility == View.VISIBLE) renderStatistics()
        RideCapture.takePending(this)?.let { (service, fare, distance) ->
            applyCapturedOrder(service, fare, distance)
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            orderReceiver,
            android.content.IntentFilter(RideCapture.ACTION_ORDER_CAPTURED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        unregisterReceiver(orderReceiver)
        super.onStop()
    }

    private fun updateSubscriptionCard() {
        // In production check via PlayBillingManager or SharedPreferences / Firestore
        if (isSubscribed) {
            tvSubTitle.text = getString(R.string.subscription_active)
            tvSubStatus.text = "Підписка діє"
            tvSubStatus.setTextColor(Color.parseColor("#32BB78"))
        } else {
            tvSubTitle.text = getString(R.string.subscription_title)
            tvSubStatus.text = getString(R.string.subscription_inactive) + " • Натисніть, щоб оформити"
            tvSubStatus.setTextColor(Color.parseColor("#B0BEC5"))
        }
    }

    private val costPerKm: Double
        get() = preferences.getFloat(KEY_COST_PER_KM, DEFAULT_COST_PER_KM.toFloat()).toDouble()

    private val commissionPercent: Double
        get() = preferences.getFloat(KEY_COMMISSION, DEFAULT_COMMISSION.toFloat()).toDouble()

    private fun updateSettingsLabels() {
        tvPriceValue.text = "${formatNumber(costPerKm)} ₴/км"
        tvCommissionValue.text = "${formatNumber(commissionPercent)}%"
        findViewById<TextView>(R.id.tvSettingCarCost).text = "${formatNumber(costPerKm)} ₴/км"
        findViewById<TextView>(R.id.tvSettingCommission).text = "${formatNumber(commissionPercent)}%"
        val idleRate = preferences.getFloat(KEY_IDLE_RATE, 0f).toDouble()
        findViewById<TextView>(R.id.tvSettingIdleRate).text = if (idleRate > 0) "${formatNumber(idleRate)} ₴/год" else "Не задано"
    }

    private fun setupSettingsScreen() {
        findViewById<SwitchMaterial>(R.id.switchSound).apply {
            isChecked = DriverPrefs.prefs(this@MainActivity).getBoolean(DriverPrefs.SOUND_ENABLED, false)
            setOnCheckedChangeListener { _, checked ->
                DriverPrefs.prefs(this@MainActivity).edit().putBoolean(DriverPrefs.SOUND_ENABLED, checked).apply()
            }
        }
        findViewById<SwitchMaterial>(R.id.switchOverlay).apply {
            isChecked = DriverPrefs.prefs(this@MainActivity).getBoolean(DriverPrefs.OVERLAY_ENABLED, true) &&
                Settings.canDrawOverlays(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                if (checked && !Settings.canDrawOverlays(this@MainActivity)) {
                    isChecked = false
                    showOverlayDisclosure()
                    return@setOnCheckedChangeListener
                }
                DriverPrefs.prefs(this@MainActivity).edit().putBoolean(DriverPrefs.OVERLAY_ENABLED, checked).apply()
            }
        }
        findViewById<View>(R.id.settingTheme).setOnClickListener { showThemeChoices() }
        findViewById<View>(R.id.settingTelegram).setOnClickListener {
            Toast.makeText(this, "Посилання на Telegram-групу ще не налаштовано", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialCardView>(R.id.cardSubscriptionSettings).setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnOpenDriverSettings).setOnClickListener {
            startActivity(Intent(this, DriverToolsActivity::class.java))
        }
        refreshSettingsScreen()
    }

    private fun refreshSettingsScreen() {
        if (!::settingsScroll.isInitialized) return
        findViewById<SwitchMaterial>(R.id.switchSound).isChecked =
            DriverPrefs.prefs(this).getBoolean(DriverPrefs.SOUND_ENABLED, false)
        findViewById<SwitchMaterial>(R.id.switchOverlay).isChecked =
            DriverPrefs.prefs(this).getBoolean(DriverPrefs.OVERLAY_ENABLED, true) && Settings.canDrawOverlays(this)
        findViewById<TextView>(R.id.tvSettingTheme).text = when (preferences.getInt(KEY_THEME_MODE, 0)) {
            1 -> "Світла"
            2 -> "За системою"
            else -> "Темна"
        }
        findViewById<TextView>(R.id.tvSettingsPremium).text = if (isSubscribed) "Підписка активна" else "Неактивна • натисніть, щоб оформити"
    }

    private fun openCarCostSetting() {
        showNumberSettingDialog(
            title = getString(R.string.car_cost_dialog_title), preferenceKey = KEY_COST_PER_KM,
            currentValue = costPerKm, minimum = 0.0, maximum = 100_000.0
        )
    }

    private fun openCommissionSetting() {
        showNumberSettingDialog(
            title = getString(R.string.commission_dialog_title), preferenceKey = KEY_COMMISSION,
            currentValue = commissionPercent, minimum = 0.0, maximum = 100.0
        )
    }

    private fun showThemeChoices() {
        val selected = preferences.getInt(KEY_THEME_MODE, 0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Тема застосунку")
            .setSingleChoiceItems(arrayOf("Темна", "Світла", "За системою"), selected) { dialog, which ->
                preferences.edit().putInt(KEY_THEME_MODE, which).apply()
                AppCompatDelegate.setDefaultNightMode(
                    when (which) {
                        1 -> AppCompatDelegate.MODE_NIGHT_NO
                        2 -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                        else -> AppCompatDelegate.MODE_NIGHT_YES
                    }
                )
                dialog.dismiss()
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    private fun showNumberSettingDialog(
        title: String,
        preferenceKey: String,
        currentValue: Double,
        minimum: Double,
        maximum: Double
    ) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(currentValue.toString())
            setSelection(text.length)
            hint = "0"
            setPadding(48, 32, 48, 24)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val value = parseNumber(input.text.toString())
                if (value == null || value < minimum || value > maximum) {
                    Toast.makeText(this, getString(R.string.invalid_setting), Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                preferences.edit().putFloat(preferenceKey, value.toFloat()).apply()
                updateSettingsLabels()
                Toast.makeText(this, getString(R.string.value_saved), Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun calculateTrip() {
        val fare = parseNumber(etTripAmount.text?.toString().orEmpty())
        val distance = parseNumber(etTripDistance.text?.toString().orEmpty())
        if (fare == null || distance == null || fare <= 0.0 || distance <= 0.0) {
            etTripAmount.error = if (fare == null || fare <= 0.0) getString(R.string.invalid_trip) else null
            etTripDistance.error = if (distance == null || distance <= 0.0) getString(R.string.invalid_trip) else null
            return
        }

        etTripAmount.error = null
        etTripDistance.error = null
        val commission = fare * commissionPercent / 100.0
        val vehicleCost = distance * costPerKm
        val net = fare - commission - vehicleCost

        tvNetResult.text = formatMoney(net)
        tvNetResult.setTextColor(getColor(if (net >= 0.0) R.color.primary else R.color.error))
        tvOrderBreakdown.text = getString(
            R.string.calculator_breakdown,
            formatMoney(commission),
            formatMoney(vehicleCost)
        )
        tvPerKm.text = getString(R.string.net_per_km, formatMoney(net / distance))
        layoutCalcResult.visibility = View.VISIBLE
    }

    private fun parseNumber(raw: String): Double? =
        raw.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }

    private fun formatNumber(value: Double): String = numberFormat.format(value)

    private fun formatMoney(value: Double): String = "${numberFormat.format(value)} ₴"

    private fun showAccessChoices() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.accessibility_disclosure_title)
            .setMessage(R.string.accessibility_disclosure)
            .setPositiveButton(R.string.enable_screen_reading) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton(R.string.enable_notifications) { _, _ -> showNotificationDisclosure() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showNotificationDisclosure() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.notification_listener_label)
            .setMessage(R.string.notification_access_disclosure)
            .setPositiveButton(R.string.enable_notifications) { _, _ ->
                runCatching { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
                    .onFailure { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showOverlayDisclosure() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.overlay_disclosure_title)
            .setMessage(R.string.overlay_disclosure)
            .setPositiveButton(R.string.allow_overlay) { _, _ ->
                if (!Settings.canDrawOverlays(this)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openServiceApp(name: String, packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
            return
        }
        MaterialAlertDialogBuilder(this)
            .setMessage(getString(R.string.app_not_installed, name))
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.install) { _, _ ->
                val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                runCatching { startActivity(market) }.onFailure {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
                }
            }
            .show()
    }

    private fun updateIntegrationStatus() {
        val screenReaderOn = isAccessibilityEnabled()
        val notificationsOn = isNotificationAccessEnabled()
        val overlayOn = Settings.canDrawOverlays(this)
        setPermissionRow(tvScreenAccessStatus, screenReaderOn, "Доступ до екрана")
        setPermissionRow(tvNotificationStatus, notificationsOn, "Сповіщення")
        tvNotificationAccessStatus.text = if (screenReaderOn || notificationsOn) getString(R.string.notification_access_on) else getString(R.string.notification_access_off)
        tvNotificationAccessStatus.setTextColor(if (screenReaderOn || notificationsOn) getColor(R.color.primary) else getColor(R.color.on_surface_variant))
        tvUklonStatus.text = installedStatus("ua.com.uklon.uklondriver")
        tvBoltStatus.text = installedStatus("ee.mtakso.driver")
        tvUberStatus.text = installedStatus("com.ubercab.driver")
        setPermissionRow(tvOverlayAccess, overlayOn, "Плаваючий розрахунок")
        val ready = listOf(screenReaderOn, notificationsOn, overlayOn).count { it }
        val percent = (ready * 100) / 3
        tvPermissionsTitle.text = "Налаштування • $ready з 3"
        tvPermissionsProgress.text = "$percent%"
        progressPermissions.progress = ready
        tvScreenAccessStatus.setOnClickListener { showAccessChoices() }
        tvNotificationStatus.setOnClickListener { showNotificationDisclosure() }
        tvBoltStatus.setTextColor(getColor(if (tvBoltStatus.text.toString().startsWith("●")) R.color.primary else R.color.on_surface_variant))
        tvUklonStatus.setTextColor(getColor(if (tvUklonStatus.text.toString().startsWith("●")) R.color.primary else R.color.on_surface_variant))
        tvUberStatus.setTextColor(getColor(if (tvUberStatus.text.toString().startsWith("●")) R.color.primary else R.color.on_surface_variant))
        updateRadarState()
    }

    private fun setPermissionRow(view: TextView, enabled: Boolean, label: String) {
        view.text = "${if (enabled) "✓" else "○"}  $label"
        view.setTextColor(getColor(if (enabled) R.color.primary else if (label.contains("Плаваючий")) R.color.secondary else R.color.on_surface_variant))
    }

    private fun updateRadarState() {
        val enabled = DriverPrefs.prefs(this).getBoolean(DriverPrefs.MONITORING, true)
        if (switchRadar.isChecked != enabled) switchRadar.isChecked = enabled
        tvRadarTitle.text = if (enabled) "Радар увімкнено" else "Радар на паузі"
        tvRadarBadge.text = if (enabled) "●  АКТИВНИЙ" else "●  ПАУЗА"
        tvRadarBadge.setTextColor(getColor(if (enabled) R.color.primary else R.color.on_surface_variant))
        tvRadarSwitchLabel.text = if (enabled) "Увімк." else "Вимк."
    }

    private fun updateDailyStats() {
        val p = DriverPrefs.prefs(this)
        val revenue = listOf("bolt", "uklon", "uber").sumOf { p.getFloat("accepted_stats_today_${it}_revenue", 0f).toDouble() }
        val trips = listOf("bolt", "uklon", "uber").sumOf { p.getInt("accepted_stats_today_${it}_trips", 0) }
        val dayStart = p.getLong("accepted_stats_day_started_at", 0L)
        val hours = if (dayStart > 0L) ((System.currentTimeMillis() - dayStart) / 3_600_000.0).coerceAtLeast(1.0 / 60.0) else 0.0
        val perHour = if (hours > 0.0) revenue / hours else 0.0
        tvTodayRevenue.text = "${revenue.toInt()} ₴"
        tvTodayTrips.text = trips.toString()
        tvHourlyRevenue.text = "${perHour.toInt()} ₴"
    }

    private data class TripRecord(val timestamp: Long, val service: String, val fare: Double, val distance: Double)
    private data class TripTotals(val net: Double, val commission: Double, val distance: Double, val trips: Int)

    private fun readTripHistory(): List<TripRecord> {
        val array = runCatching { JSONArray(DriverPrefs.prefs(this).getString(DriverPrefs.ACCEPTED_HISTORY, "[]")) }
            .getOrElse { JSONArray() }
        return (0 until array.length()).mapNotNull { index ->
            val row = array.optJSONObject(index) ?: return@mapNotNull null
            TripRecord(
                timestamp = row.optLong("timestamp"),
                service = row.optString("service", "Поїздка"),
                fare = row.optDouble("fare", 0.0).coerceAtLeast(0.0),
                distance = row.optDouble("distance", 0.0).coerceAtLeast(0.0)
            )
        }
    }

    private fun periodBounds(period: Int, now: Long): Pair<Calendar, Calendar> {
        val start = Calendar.getInstance().apply { timeInMillis = now }
        start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0)
        start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
        when (period) {
            R.id.btnStatsWeek -> {
                val offset = (start.get(Calendar.DAY_OF_WEEK) + 5) % 7
                start.add(Calendar.DAY_OF_YEAR, -offset)
            }
            R.id.btnStatsMonth -> start.set(Calendar.DAY_OF_MONTH, 1)
        }
        return start to Calendar.getInstance().apply { timeInMillis = now }
    }

    private fun totalsFor(records: List<TripRecord>): TripTotals {
        val commissionRate = commissionPercent / 100.0
        var net = 0.0
        var commission = 0.0
        var distance = 0.0
        records.forEach { row ->
            val fee = row.fare * commissionRate
            commission += fee
            net += row.fare - fee - row.distance * costPerKm
            distance += row.distance
        }
        return TripTotals(net, commission, distance, records.size)
    }

    private fun renderStatistics() {
        if (!::statsScroll.isInitialized) return
        val now = System.currentTimeMillis()
        val (start, end) = periodBounds(statsPeriod, now)
        val startAt = start.timeInMillis
        val endAt = end.timeInMillis
        var records = readTripHistory().filter { it.timestamp >= startAt && it.timestamp < endAt }
        var legacyToday = false
        var totals = totalsFor(records)
        val prefs = DriverPrefs.prefs(this)

        if (records.isEmpty() && statsPeriod == R.id.btnStatsDay) {
            val todayKey = SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(Date(now))
            if (prefs.getString("accepted_stats_day", "") == todayKey) {
                val legacyRevenue = listOf("bolt", "uklon", "uber").sumOf {
                    prefs.getFloat("accepted_stats_today_${it}_revenue", 0f).toDouble()
                }
                val legacyTrips = listOf("bolt", "uklon", "uber").sumOf {
                    prefs.getInt("accepted_stats_today_${it}_trips", 0)
                }
                if (legacyRevenue > 0.0 || legacyTrips > 0) {
                    legacyToday = true
                    val legacyCommission = legacyRevenue * commissionPercent / 100.0
                    totals = TripTotals(legacyRevenue - legacyCommission, legacyCommission, 0.0, legacyTrips)
                }
            }
        }

        val revenue = findViewById<TextView>(R.id.tvStatsNetRevenue)
        revenue.text = formatMoney(totals.net)
        revenue.setTextColor(getColor(if (totals.net >= 0) R.color.secondary else R.color.error))
        val buckets = MutableList(7) { 0.0 }
        val span = when (statsPeriod) {
            R.id.btnStatsWeek -> 7L * 24 * 60 * 60 * 1000
            R.id.btnStatsMonth -> start.getActualMaximum(Calendar.DAY_OF_MONTH).toLong() * 24 * 60 * 60 * 1000
            else -> 24L * 60 * 60 * 1000
        }
        records.forEach { row ->
            val index = (((row.timestamp - startAt).toDouble() / span) * buckets.size).toInt().coerceIn(0, 6)
            val fee = row.fare * commissionPercent / 100.0
            buckets[index] += row.fare - fee - row.distance * costPerKm
        }
        if (legacyToday && totals.net > 0.0) {
            val index = ((now - startAt) / (24.0 * 60 * 60 * 1000) * buckets.size).toInt().coerceIn(0, 6)
            buckets[index] = totals.net
        }
        val currentBucket = when (statsPeriod) {
            R.id.btnStatsWeek -> ((Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7)
            R.id.btnStatsMonth -> (((Calendar.getInstance().get(Calendar.DAY_OF_MONTH) - 1).toDouble() / start.getActualMaximum(Calendar.DAY_OF_MONTH)) * 7).toInt().coerceIn(0, 6)
            else -> ((Calendar.getInstance().get(Calendar.HOUR_OF_DAY).toDouble() / 24.0) * 7).toInt().coerceIn(0, 6)
        }
        drawStatisticsChart(buckets, statsPeriod, currentBucket)
        findViewById<TextView>(R.id.tvStatsFootnote).text = when {
            legacyToday -> "Попередній підсумок дня без збереженого пробігу"
            records.isEmpty() -> "Суми з’являться після позначення поїздок як «Прийняв»"
            else -> "Дані зарахованих вручну поїздок • ${periodTitle(statsPeriod)}"
        }

        val periodDuration = when (statsPeriod) {
            R.id.btnStatsWeek -> Calendar.DAY_OF_YEAR to 7
            R.id.btnStatsMonth -> Calendar.MONTH to 1
            else -> Calendar.DAY_OF_YEAR to 1
        }
        val previousStart = (start.clone() as Calendar).apply { add(periodDuration.first, -periodDuration.second) }
        val previousRecords = readTripHistory().filter {
            it.timestamp >= previousStart.timeInMillis && it.timestamp < startAt
        }
        val previousTotals = totalsFor(previousRecords)
        val deltaText = if (previousTotals.net > 0.0) {
            val percent = ((totals.net - previousTotals.net) / previousTotals.net) * 100.0
            "${if (percent >= 0) "+" else ""}${percent.toInt()}% до попереднього періоду"
        } else "Порівняння з попереднім періодом з’явиться з часом"
        findViewById<TextView>(R.id.tvStatsDelta).apply {
            text = deltaText
            setTextColor(getColor(if (previousTotals.net <= 0.0 || totals.net >= previousTotals.net) R.color.primary else R.color.error))
        }

        setStatsTile(R.id.tileStatsTrips, "Поїздки", totals.trips.toString())
        setStatsTile(R.id.tileStatsDistance, "Пробіг", "${formatNumber(totals.distance)} км")
        setStatsTile(R.id.tileStatsPerKm, "Чистими за км", if (totals.distance > 0.0) "${formatNumber(totals.net / totals.distance)} ₴" else "—")
        setStatsTile(R.id.tileStatsCommission, "Комісія", formatMoney(totals.commission))
        renderRecentOrders(records, legacyToday)
    }

    private fun periodTitle(period: Int): String = when (period) {
        R.id.btnStatsWeek -> "тиждень"
        R.id.btnStatsMonth -> "місяць"
        else -> "сьогодні"
    }

    private fun setStatsTile(tileId: Int, label: String, value: String) {
        val tile = findViewById<View>(tileId)
        tile.findViewById<TextView>(R.id.tvLabel).text = label
        tile.findViewById<TextView>(R.id.tvValue).text = value
    }

    private fun drawStatisticsChart(values: List<Double>, period: Int, currentBucket: Int) {
        val host = findViewById<LinearLayout>(R.id.statsBars)
        host.removeAllViews()
        val maxValue = values.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
        val dayLabels = listOf("00", "04", "08", "12", "16", "20", "24")
        val weekLabels = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
        val monthLabels = listOf("1–4", "5–8", "9–12", "13–16", "17–20", "21–24", "25+")
        val labels = when (period) {
            R.id.btnStatsWeek -> weekLabels
            R.id.btnStatsMonth -> monthLabels
            else -> dayLabels
        }
        values.forEachIndexed { index, value ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            val slot = FrameLayout(this)
            val height = if (value > 0.0) (value / maxValue * dp(68)).toInt().coerceAtLeast(dp(4)) else dp(3)
            val bar = View(this).apply {
                background = GradientDrawable().apply {
                    setColor(getColor(if (index == currentBucket) R.color.primary else R.color.surface_variant))
                    cornerRadii = floatArrayOf(dp(4).toFloat(), dp(4).toFloat(), dp(4).toFloat(), dp(4).toFloat(), dp(1).toFloat(), dp(1).toFloat(), dp(1).toFloat(), dp(1).toFloat())
                }
            }
            slot.addView(bar, FrameLayout.LayoutParams(dp(16), height, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            column.addView(slot, LinearLayout.LayoutParams(-1, 0, 1f))
            column.addView(TextView(this).apply {
                text = labels[index]
                textSize = 9f
                gravity = Gravity.CENTER
                setTextColor(getColor(R.color.on_surface_variant))
            }, LinearLayout.LayoutParams(-1, dp(14)))
            host.addView(column, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun renderRecentOrders(records: List<TripRecord>, legacyToday: Boolean) {
        val host = findViewById<LinearLayout>(R.id.statsRecentOrders)
        host.removeAllViews()
        if (records.isEmpty()) {
            val summary = if (legacyToday) DriverPrefs.prefs(this).getString(DriverPrefs.LAST_ACCEPTED_SUMMARY, null) else null
            host.addView(TextView(this).apply {
                text = summary ?: "Поки немає збережених поїздок. Позначайте прийняття у розділі «Таймери поїздки»."
                textSize = 13f
                setTextColor(getColor(R.color.on_surface_variant))
                setPadding(dp(10), dp(14), dp(10), dp(14))
            })
            return
        }
        val formatter = SimpleDateFormat("dd.MM • HH:mm", Locale.forLanguageTag("uk-UA"))
        records.sortedByDescending { it.timestamp }.take(6).forEach { row ->
            val fee = row.fare * commissionPercent / 100.0
            val net = row.fare - fee - row.distance * costPerKm
            val card = MaterialCardView(this).apply {
                radius = dp(15).toFloat()
                cardElevation = 0f
                setCardBackgroundColor(getColor(R.color.surface))
                strokeWidth = dp(1)
                setStrokeColor(getColor(R.color.outline))
            }
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(TextView(this).apply {
                text = "${row.service}  •  ${formatter.format(Date(row.timestamp))}"
                textSize = 13f
                setTextColor(getColor(R.color.on_surface))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            details.addView(TextView(this).apply {
                text = if (row.distance > 0.0) "${formatMoney(row.fare)} • ${formatNumber(row.distance)} км" else "Суму або відстань не розпізнано"
                textSize = 11f
                setTextColor(getColor(R.color.on_surface_variant))
                setPadding(0, dp(3), 0, 0)
            })
            line.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(TextView(this).apply {
                text = if (row.fare > 0) "${if (net >= 0) "+" else ""}${formatMoney(net)}" else "—"
                textSize = 13f
                setTextColor(getColor(if (net >= 0) R.color.primary else R.color.error))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            card.addView(line)
            host.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun selectBottomTab(selectedId: Int) {
        val items = listOf(
            Triple(R.id.navHome, R.id.navMarkHome, R.color.primary),
            Triple(R.id.navCalculator, R.id.navMarkCalculator, R.color.on_surface_variant),
            Triple(R.id.navStatistics, R.id.navMarkStatistics, R.color.on_surface_variant),
            Triple(R.id.navSettings, R.id.navMarkSettings, R.color.on_surface_variant)
        )
        items.forEach { (itemId, markerId, _) ->
            val item = findViewById<LinearLayout>(itemId)
            val active = itemId == selectedId
            findViewById<View>(markerId).visibility = if (active) View.VISIBLE else View.INVISIBLE
            val color = getColor(if (active) R.color.primary else R.color.on_surface_variant)
            for (i in 1 until item.childCount) (item.getChildAt(i) as? TextView)?.setTextColor(color)
        }
        homeScroll.visibility = if (selectedId == R.id.navStatistics || selectedId == R.id.navSettings) View.GONE else View.VISIBLE
        statsScroll.visibility = if (selectedId == R.id.navStatistics) View.VISIBLE else View.GONE
        settingsScroll.visibility = if (selectedId == R.id.navSettings) View.VISIBLE else View.GONE
        when (selectedId) {
            R.id.navHome, R.id.navCalculator -> homeScroll.smoothScrollTo(0, if (selectedId == R.id.navHome) 0 else homeScroll.scrollY)
            R.id.navStatistics -> statsScroll.smoothScrollTo(0, 0)
            R.id.navSettings -> settingsScroll.smoothScrollTo(0, 0)
        }
    }

    private fun installedStatus(packageName: String): String = try {
        packageManager.getApplicationInfo(packageName, 0)
        "●  Встановлено"
    } catch (_: Exception) {
        "○  Не встановлено"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Secure.getString(contentResolver, Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val component = ComponentName(this, RideAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        val component = ComponentName(this, RideNotificationListener::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun applyCapturedOrder(service: String, fare: Double?, distance: Double?) {
        if (fare != null) etTripAmount.setText(formatNumber(fare))
        if (distance != null) etTripDistance.setText(formatNumber(distance))
        if (fare != null && distance != null) calculateTrip()
        Toast.makeText(
            this,
            getString(if (fare != null || distance != null) R.string.order_values_detected else R.string.order_detected, service),
            Toast.LENGTH_LONG
        ).show()
    }

    companion object {
        private const val KEY_COST_PER_KM = "cost_per_km"
        private const val KEY_COMMISSION = "commission_percent"
        private const val KEY_IDLE_RATE = "idle_rate_per_hour"
        private const val KEY_STATS_PERIOD = "stats_period_id"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val DEFAULT_COST_PER_KM = 9.0
        private const val DEFAULT_COMMISSION = 15.0
    }
}
