package ua.taximoney.taxiscan

import android.content.Intent
import android.content.ComponentName
import android.provider.Settings
import android.net.Uri
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings.Secure
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvSubTitle: TextView
    private lateinit var tvSubStatus: TextView
    private lateinit var tvPriceValue: TextView
    private lateinit var tvCommissionValue: TextView
    private lateinit var etTripAmount: EditText
    private lateinit var etTripDistance: EditText
    private lateinit var layoutCalcResult: View
    private lateinit var tvNetResult: TextView
    private lateinit var tvOrderBreakdown: TextView
    private lateinit var tvPerKm: TextView
    private lateinit var tvNotificationAccessStatus: TextView
    private lateinit var tvUklonStatus: TextView
    private lateinit var tvBoltStatus: TextView
    private lateinit var tvUberStatus: TextView
    private lateinit var tvOverlayAccess: TextView
    private var isSubscribed = false
    private val preferences by lazy { getSharedPreferences("taxiscan_settings", MODE_PRIVATE) }
    private val numberFormat by lazy {
        NumberFormat.getNumberInstance(Locale.forLanguageTag("uk-UA")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
    }
    private val orderReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action != RideCapture.ACTION_ORDER_CAPTURED) return
            applyCapturedOrder(
                intent.getStringExtra(RideCapture.EXTRA_SERVICE).orEmpty(),
                intent.getDoubleExtra(RideCapture.EXTRA_FARE, -1.0).takeIf { it > 0 },
                intent.getDoubleExtra(RideCapture.EXTRA_DISTANCE, -1.0).takeIf { it > 0 }
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSubTitle = findViewById(R.id.tvSubTitle)
        tvSubStatus = findViewById(R.id.tvSubStatus)
        tvPriceValue = findViewById(R.id.tvPriceValue)
        tvCommissionValue = findViewById(R.id.tvCommissionValue)
        etTripAmount = findViewById(R.id.etTripAmount)
        etTripDistance = findViewById(R.id.etTripDistance)
        layoutCalcResult = findViewById(R.id.layoutCalcResult)
        tvNetResult = findViewById(R.id.tvNetResult)
        tvOrderBreakdown = findViewById(R.id.tvOrderBreakdown)
        tvPerKm = findViewById(R.id.tvPerKm)
        tvNotificationAccessStatus = findViewById(R.id.tvNotificationAccessStatus)
        tvUklonStatus = findViewById(R.id.tvUklonStatus)
        tvBoltStatus = findViewById(R.id.tvBoltStatus)
        tvUberStatus = findViewById(R.id.tvUberStatus)
        tvOverlayAccess = findViewById(R.id.btnOverlayAccess)
        updateSettingsLabels()

        findViewById<MaterialButton>(R.id.btnCalculate).setOnClickListener {
            calculateTrip()
        }

        findViewById<View>(R.id.itemPrice).setOnClickListener {
            showNumberSettingDialog(
                title = getString(R.string.car_cost_dialog_title),
                preferenceKey = KEY_COST_PER_KM,
                currentValue = costPerKm,
                minimum = 0.0,
                maximum = 100_000.0
            )
        }

        findViewById<View>(R.id.itemCommission).setOnClickListener {
            showNumberSettingDialog(
                title = getString(R.string.commission_dialog_title),
                preferenceKey = KEY_COMMISSION,
                currentValue = commissionPercent,
                minimum = 0.0,
                maximum = 100.0
            )
        }

        findViewById<MaterialCardView>(R.id.cardSubscription).setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardUklon).setOnClickListener {
            openServiceApp("Uklon", "ua.com.uklon.uklondriver")
        }

        findViewById<MaterialCardView>(R.id.cardBolt).setOnClickListener {
            openServiceApp("Bolt", "ee.mtakso.driver")
        }
        findViewById<MaterialCardView>(R.id.cardUber).setOnClickListener {
            openServiceApp("Uber", "com.ubercab.driver")
        }

        findViewById<MaterialButton>(R.id.btnNotificationAccess).setOnClickListener {
            showAccessChoices()
        }
        tvOverlayAccess.setOnClickListener { showOverlayDisclosure() }
        findViewById<MaterialButton>(R.id.btnSystemPermissions).setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        findViewById<View>(R.id.btnDriverTools).setOnClickListener {
            startActivity(Intent(this, DriverToolsActivity::class.java))
        }

        if (savedInstanceState == null && preferences.getBoolean(DriverPrefs.AUTO_LAUNCH_BOLT, false)) {
            openServiceApp("Bolt", "ee.mtakso.driver")
        }

        findViewById<TextView>(R.id.tvJoinGroup).setOnClickListener {
            Toast.makeText(this, getString(R.string.service_not_connected), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        updateSubscriptionCard()
        updateIntegrationStatus()
        RideCapture.takePending(this)?.let { (service, fare, distance) ->
            applyCapturedOrder(service, fare, distance)
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            orderReceiver,
            android.content.IntentFilter(RideCapture.ACTION_ORDER_CAPTURED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        unregisterReceiver(orderReceiver)
        super.onStop()
    }

    private fun updateSubscriptionCard() {
        // In production check via PlayBillingManager or SharedPreferences / Firestore
        if (isSubscribed) {
            tvSubTitle.text = getString(R.string.subscription_active)
            tvSubStatus.text = "Підписка діє"
            tvSubStatus.setTextColor(Color.parseColor("#32BB78"))
        } else {
            tvSubTitle.text = getString(R.string.subscription_title)
            tvSubStatus.text = getString(R.string.subscription_inactive) + " • Натисніть, щоб оформити"
            tvSubStatus.setTextColor(Color.parseColor("#B0BEC5"))
        }
    }

    private val costPerKm: Double
        get() = preferences.getFloat(KEY_COST_PER_KM, DEFAULT_COST_PER_KM.toFloat()).toDouble()

    private val commissionPercent: Double
        get() = preferences.getFloat(KEY_COMMISSION, DEFAULT_COMMISSION.toFloat()).toDouble()

    private fun updateSettingsLabels() {
        tvPriceValue.text = "${formatNumber(costPerKm)} ₴/км"
        tvCommissionValue.text = "${formatNumber(commissionPercent)}%"
    }

    private fun showNumberSettingDialog(
        title: String,
        preferenceKey: String,
        currentValue: Double,
        minimum: Double,
        maximum: Double
    ) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(currentValue.toString())
            setSelection(text.length)
            hint = "0"
            setPadding(48, 32, 48, 24)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val value = parseNumber(input.text.toString())
                if (value == null || value < minimum || value > maximum) {
                    Toast.makeText(this, getString(R.string.invalid_setting), Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                preferences.edit().putFloat(preferenceKey, value.toFloat()).apply()
                updateSettingsLabels()
                Toast.makeText(this, getString(R.string.value_saved), Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun calculateTrip() {
        val fare = parseNumber(etTripAmount.text?.toString().orEmpty())
        val distance = parseNumber(etTripDistance.text?.toString().orEmpty())
        if (fare == null || distance == null || fare <= 0.0 || distance <= 0.0) {
            etTripAmount.error = if (fare == null || fare <= 0.0) getString(R.string.invalid_trip) else null
            etTripDistance.error = if (distance == null || distance <= 0.0) getString(R.string.invalid_trip) else null
            return
        }

        etTripAmount.error = null
        etTripDistance.error = null
        val commission = fare * commissionPercent / 100.0
        val vehicleCost = distance * costPerKm
        val net = fare - commission - vehicleCost

        tvNetResult.text = formatMoney(net)
        tvNetResult.setTextColor(getColor(if (net >= 0.0) R.color.primary else R.color.error))
        tvOrderBreakdown.text = getString(
            R.string.calculator_breakdown,
            formatMoney(commission),
            formatMoney(vehicleCost)
        )
        tvPerKm.text = getString(R.string.net_per_km, formatMoney(net / distance))
        layoutCalcResult.visibility = View.VISIBLE
    }

    private fun parseNumber(raw: String): Double? =
        raw.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }

    private fun formatNumber(value: Double): String = numberFormat.format(value)

    private fun formatMoney(value: Double): String = "${numberFormat.format(value)} ₴"

    private fun showAccessChoices() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.accessibility_disclosure_title)
            .setMessage(R.string.accessibility_disclosure)
            .setPositiveButton(R.string.enable_screen_reading) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton(R.string.enable_notifications) { _, _ -> showNotificationDisclosure() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showNotificationDisclosure() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.notification_listener_label)
            .setMessage(R.string.notification_access_disclosure)
            .setPositiveButton(R.string.enable_notifications) { _, _ ->
                runCatching { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
                    .onFailure { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showOverlayDisclosure() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.overlay_disclosure_title)
            .setMessage(R.string.overlay_disclosure)
            .setPositiveButton(R.string.allow_overlay) { _, _ ->
                if (!Settings.canDrawOverlays(this)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openServiceApp(name: String, packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
            return
        }
        MaterialAlertDialogBuilder(this)
            .setMessage(getString(R.string.app_not_installed, name))
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.install) { _, _ ->
                val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                runCatching { startActivity(market) }.onFailure {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")))
                }
            }
            .show()
    }

    private fun updateIntegrationStatus() {
        val screenReaderOn = isAccessibilityEnabled()
        val notificationsOn = isNotificationAccessEnabled()
        tvNotificationAccessStatus.setText(
            if (screenReaderOn || notificationsOn) R.string.notification_access_on
            else R.string.notification_access_off
        )
        tvUklonStatus.text = installedStatus("ua.com.uklon.uklondriver")
        tvBoltStatus.text = installedStatus("ee.mtakso.driver")
        tvUberStatus.text = installedStatus("com.ubercab.driver")
        tvOverlayAccess.setText(
            if (Settings.canDrawOverlays(this)) R.string.overlay_access_on
            else R.string.overlay_access_off
        )
    }

    private fun installedStatus(packageName: String): String = try {
        packageManager.getApplicationInfo(packageName, 0)
        getString(R.string.app_installed)
    } catch (_: Exception) {
        getString(R.string.app_not_installed_short)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Secure.getString(contentResolver, Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val component = ComponentName(this, RideAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        val component = ComponentName(this, RideNotificationListener::class.java).flattenToString()
        return enabled.split(':').any { it.equals(component, ignoreCase = true) }
    }

    private fun applyCapturedOrder(service: String, fare: Double?, distance: Double?) {
        if (fare != null) etTripAmount.setText(formatNumber(fare))
        if (distance != null) etTripDistance.setText(formatNumber(distance))
        if (fare != null && distance != null) calculateTrip()
        Toast.makeText(
            this,
            getString(if (fare != null || distance != null) R.string.order_values_detected else R.string.order_detected, service),
            Toast.LENGTH_LONG
        ).show()
    }

    companion object {
        private const val KEY_COST_PER_KM = "cost_per_km"
        private const val KEY_COMMISSION = "commission_percent"
        private const val DEFAULT_COST_PER_KM = 9.0
        private const val DEFAULT_COMMISSION = 15.0
    }
}
