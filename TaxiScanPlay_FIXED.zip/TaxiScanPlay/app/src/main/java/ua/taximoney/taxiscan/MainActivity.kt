package ua.taximoney.taxiscan

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var tvSubTitle: TextView
    private lateinit var tvSubStatus: TextView
    private var isSubscribed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSubTitle = findViewById(R.id.tvSubTitle)
        tvSubStatus = findViewById(R.id.tvSubStatus)

        findViewById<MaterialCardView>(R.id.cardSubscription).setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardUklon).setOnClickListener {
            // TODO: open Uklon settings
        }

        findViewById<MaterialCardView>(R.id.cardBolt).setOnClickListener {
            // TODO: open Bolt settings
        }

        findViewById<TextView>(R.id.tvJoinGroup).setOnClickListener {
            // TODO: open Telegram / chat group
        }
    }

    override fun onResume() {
        super.onResume()
        updateSubscriptionCard()
    }

    private fun updateSubscriptionCard() {
        // In production check via PlayBillingManager or SharedPreferences / Firestore
        if (isSubscribed) {
            tvSubTitle.text = getString(R.string.subscription_active)
            tvSubStatus.text = "Підписка діє"
            tvSubStatus.setTextColor(Color.parseColor("#32BB78"))
        } else {
            tvSubTitle.text = getString(R.string.subscription_title)
            tvSubStatus.text = getString(R.string.subscription_inactive) + " • Натисніть, щоб оформити"
            tvSubStatus.setTextColor(Color.parseColor("#B0BEC5"))
        }
    }
}
