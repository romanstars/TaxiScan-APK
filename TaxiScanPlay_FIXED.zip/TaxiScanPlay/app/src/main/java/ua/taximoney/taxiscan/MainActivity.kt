package ua.taximoney.taxiscan

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvSubTitle: TextView
    private lateinit var tvSubStatus: TextView
    private lateinit var tvPriceValue: TextView
    private lateinit var tvCommissionValue: TextView
    private lateinit var etTripAmount: EditText
    private lateinit var etTripDistance: EditText
    private lateinit var layoutCalcResult: View
    private lateinit var tvNetResult: TextView
    private lateinit var tvOrderBreakdown: TextView
    private lateinit var tvPerKm: TextView
    private var isSubscribed = false
    private val preferences by lazy { getSharedPreferences("taxiscan_settings", MODE_PRIVATE) }
    private val numberFormat by lazy {
        NumberFormat.getNumberInstance(Locale.forLanguageTag("uk-UA")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSubTitle = findViewById(R.id.tvSubTitle)
        tvSubStatus = findViewById(R.id.tvSubStatus)
        tvPriceValue = findViewById(R.id.tvPriceValue)
        tvCommissionValue = findViewById(R.id.tvCommissionValue)
        etTripAmount = findViewById(R.id.etTripAmount)
        etTripDistance = findViewById(R.id.etTripDistance)
        layoutCalcResult = findViewById(R.id.layoutCalcResult)
        tvNetResult = findViewById(R.id.tvNetResult)
        tvOrderBreakdown = findViewById(R.id.tvOrderBreakdown)
        tvPerKm = findViewById(R.id.tvPerKm)
        updateSettingsLabels()

        findViewById<MaterialButton>(R.id.btnCalculate).setOnClickListener {
            calculateTrip()
        }

        findViewById<View>(R.id.itemPrice).setOnClickListener {
            showNumberSettingDialog(
                title = getString(R.string.car_cost_dialog_title),
                preferenceKey = KEY_COST_PER_KM,
                currentValue = costPerKm,
                minimum = 0.0,
                maximum = 100_000.0
            )
        }

        findViewById<View>(R.id.itemCommission).setOnClickListener {
            showNumberSettingDialog(
                title = getString(R.string.commission_dialog_title),
                preferenceKey = KEY_COMMISSION,
                currentValue = commissionPercent,
                minimum = 0.0,
                maximum = 100.0
            )
        }

        findViewById<MaterialCardView>(R.id.cardSubscription).setOnClickListener {
            startActivity(Intent(this, SubscriptionActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardUklon).setOnClickListener {
            showServiceNotice()
        }

        findViewById<MaterialCardView>(R.id.cardBolt).setOnClickListener {
            showServiceNotice()
        }

        findViewById<TextView>(R.id.tvJoinGroup).setOnClickListener {
            Toast.makeText(this, getString(R.string.service_not_connected), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        updateSubscriptionCard()
    }

    private fun updateSubscriptionCard() {
        // In production check via PlayBillingManager or SharedPreferences / Firestore
        if (isSubscribed) {
            tvSubTitle.text = getString(R.string.subscription_active)
            tvSubStatus.text = "Підписка діє"
            tvSubStatus.setTextColor(Color.parseColor("#32BB78"))
        } else {
            tvSubTitle.text = getString(R.string.subscription_title)
            tvSubStatus.text = getString(R.string.subscription_inactive) + " • Натисніть, щоб оформити"
            tvSubStatus.setTextColor(Color.parseColor("#B0BEC5"))
        }
    }

    private val costPerKm: Double
        get() = preferences.getFloat(KEY_COST_PER_KM, DEFAULT_COST_PER_KM.toFloat()).toDouble()

    private val commissionPercent: Double
        get() = preferences.getFloat(KEY_COMMISSION, DEFAULT_COMMISSION.toFloat()).toDouble()

    private fun updateSettingsLabels() {
        tvPriceValue.text = "${formatNumber(costPerKm)} ₴/км"
        tvCommissionValue.text = "${formatNumber(commissionPercent)}%"
    }

    private fun showNumberSettingDialog(
        title: String,
        preferenceKey: String,
        currentValue: Double,
        minimum: Double,
        maximum: Double
    ) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(currentValue.toString())
            setSelection(text.length)
            hint = "0"
            setPadding(48, 32, 48, 24)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(input)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val value = parseNumber(input.text.toString())
                if (value == null || value < minimum || value > maximum) {
                    Toast.makeText(this, getString(R.string.invalid_setting), Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                preferences.edit().putFloat(preferenceKey, value.toFloat()).apply()
                updateSettingsLabels()
                Toast.makeText(this, getString(R.string.value_saved), Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun calculateTrip() {
        val fare = parseNumber(etTripAmount.text?.toString().orEmpty())
        val distance = parseNumber(etTripDistance.text?.toString().orEmpty())
        if (fare == null || distance == null || fare <= 0.0 || distance <= 0.0) {
            etTripAmount.error = if (fare == null || fare <= 0.0) getString(R.string.invalid_trip) else null
            etTripDistance.error = if (distance == null || distance <= 0.0) getString(R.string.invalid_trip) else null
            return
        }

        etTripAmount.error = null
        etTripDistance.error = null
        val commission = fare * commissionPercent / 100.0
        val vehicleCost = distance * costPerKm
        val net = fare - commission - vehicleCost

        tvNetResult.text = formatMoney(net)
        tvNetResult.setTextColor(getColor(if (net >= 0.0) R.color.primary else R.color.error))
        tvOrderBreakdown.text = getString(
            R.string.calculator_breakdown,
            formatMoney(commission),
            formatMoney(vehicleCost)
        )
        tvPerKm.text = getString(R.string.net_per_km, formatMoney(net / distance))
        layoutCalcResult.visibility = View.VISIBLE
    }

    private fun parseNumber(raw: String): Double? =
        raw.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }

    private fun formatNumber(value: Double): String = numberFormat.format(value)

    private fun formatMoney(value: Double): String = "${numberFormat.format(value)} ₴"

    private fun showServiceNotice() {
        Toast.makeText(this, getString(R.string.service_not_connected), Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val KEY_COST_PER_KM = "cost_per_km"
        private const val KEY_COMMISSION = "commission_percent"
        private const val DEFAULT_COST_PER_KM = 9.0
        private const val DEFAULT_COMMISSION = 15.0
    }
}
