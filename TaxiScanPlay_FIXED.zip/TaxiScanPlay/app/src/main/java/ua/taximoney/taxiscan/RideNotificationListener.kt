package ua.taximoney.taxiscan

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class RideNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val service = RideCapture.serviceName(sbn.packageName)
        if (service.isBlank()) return
        val extras = sbn.notification.extras
        val text = listOf(
            extras.getCharSequence("android.title"),
            extras.getCharSequence("android.text"),
            extras.getCharSequence("android.bigText"),
            extras.getCharSequence("android.subText")
        ).filterNotNull().joinToString(" ")
        val values = RideCapture.parse(text)
        if (values.fare != null || values.distance != null) {
            RideCapture.saveAndBroadcast(this, service, values)
        }
    }
}
