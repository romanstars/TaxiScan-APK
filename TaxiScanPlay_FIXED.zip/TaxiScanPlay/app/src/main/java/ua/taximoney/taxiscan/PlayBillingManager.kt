package ua.taximoney.taxiscan

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.*

class PlayBillingManager(
    private val context: Context,
    private val onStatusChanged: (Boolean) -> Unit
) : PurchasesUpdatedListener, BillingClientStateListener {

    companion object {
        const val SUBSCRIPTION_ID = "taxiscan_premium_monthly"
        private const val TAG = "PlayBilling"
    }

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases()
        .build()

    private var productDetails: ProductDetails? = null
    private var isConnecting = false

    fun startConnection() {
        if (billingClient.isReady || isConnecting) return
        isConnecting = true
        billingClient.startConnection(this)
    }

    fun endConnection() {
        billingClient.endConnection()
    }

    fun refreshPurchases() {
        if (billingClient.isReady) queryActivePurchases() else startConnection()
    }

    override fun onBillingSetupFinished(result: BillingResult) {
        isConnecting = false
        if (result.responseCode == BillingClient.BillingResponseCode.OK) {
            queryProduct()
            queryActivePurchases()
        } else {
            Log.e(TAG, "Billing setup failed: ${result.debugMessage}")
        }
    }

    override fun onBillingServiceDisconnected() {
        isConnecting = false
        Log.w(TAG, "Billing disconnected")
    }

    private fun queryProduct() {
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(SUBSCRIPTION_ID)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { result, detailsList ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK && detailsList.isNotEmpty()) {
                productDetails = detailsList[0]
            }
        }
    }

    private fun queryActivePurchases() {
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        billingClient.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                val hasActive = purchases.any {
                    it.products.contains(SUBSCRIPTION_ID) &&
                    it.purchaseState == Purchase.PurchaseState.PURCHASED
                }
                purchases.filter {
                    it.products.contains(SUBSCRIPTION_ID) &&
                        it.purchaseState == Purchase.PurchaseState.PURCHASED && !it.isAcknowledged
                }.forEach { acknowledgePurchase(it) }
                onStatusChanged(hasActive)
            }
        }
    }

    fun launchPurchase(activity: Activity) {
        val details = productDetails ?: return
        val offerToken = details.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return

        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(details)
            .setOfferToken(offerToken)
            .build()

        val flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))
            .build()

        billingClient.launchBillingFlow(activity, flowParams)
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: List<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                purchases?.forEach { purchase ->
                    if (purchase.products.contains(SUBSCRIPTION_ID) && purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        acknowledgePurchase(purchase)
                        onStatusChanged(true)
                    }
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> Log.d(TAG, "User canceled")
            else -> Log.e(TAG, "Purchase error: ${result.debugMessage}")
        }
    }

    private fun acknowledgePurchase(purchase: Purchase) {
        if (purchase.isAcknowledged) return
        val params = AcknowledgePurchaseParams.newBuilder()
            .setPurchaseToken(purchase.purchaseToken)
            .build()
        billingClient.acknowledgePurchase(params) { }
    }

    fun getPrice(): String {
        return productDetails
            ?.subscriptionOfferDetails
            ?.firstOrNull()
            ?.pricingPhases
            ?.pricingPhaseList
            ?.lastOrNull()
            ?.formattedPrice ?: "—"
    }

    fun getOfferDetails(): String {
        val phases = productDetails
            ?.subscriptionOfferDetails
            ?.firstOrNull()
            ?.pricingPhases
            ?.pricingPhaseList ?: return ""

        if (phases.isEmpty()) return ""
        val first = phases[0]
        return when {
            first.priceAmountMicros == 0L -> "Безкоштовний період, далі ${phases.getOrNull(1)?.formattedPrice ?: ""}/міс"
            phases.size > 1 -> "Перший період ${first.formattedPrice}, далі ${phases[1].formattedPrice}/міс"
            else -> "${first.formattedPrice} / місяць"
        }
    }

    fun hasFreeTrial(): Boolean {
        return productDetails
            ?.subscriptionOfferDetails
            ?.firstOrNull()
            ?.pricingPhases
            ?.pricingPhaseList
            ?.firstOrNull()
            ?.priceAmountMicros == 0L
    }
}
