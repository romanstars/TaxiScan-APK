package ua.taximoney.taxiscan

import android.content.Context
import android.content.Intent

/** Parses only explicit fare and distance values, then keeps them on-device. */
object RideCapture {
    const val ACTION_ORDER_CAPTURED = "ua.taximoney.taxiscan.ORDER_CAPTURED"
    const val EXTRA_SERVICE = "service"
    const val EXTRA_FARE = "fare"
    const val EXTRA_DISTANCE = "distance"
    private const val PREFS = "taxiscan_settings"
    private const val KEY_PENDING_FARE = "captured_fare"
    private const val KEY_PENDING_DISTANCE = "captured_distance"
    private const val KEY_PENDING_SERVICE = "captured_service"

    data class Values(val fare: Double?, val distance: Double?)

    fun parse(text: String): Values {
        val normalized = text.replace('\u00a0', ' ').replace(',', '.')
        val fare = Regex("(?i)(?:(?:₴|грн|uah)\\s*([0-9]+(?:\\.[0-9]{1,2})?)|([0-9]+(?:\\.[0-9]{1,2})?)\\s*(?:грн|uah|₴))")
            .find(normalized)?.let { (it.groupValues[1].ifBlank { it.groupValues[2] }).toDoubleOrNull() }
        val distance = Regex("(?i)([0-9]+(?:\\.[0-9]{1,2})?)\\s*(?:км|km)(?![A-Za-z])")
            .find(normalized)?.groupValues?.get(1)?.toDoubleOrNull()
        return Values(fare?.takeIf { it > 0.0 }, distance?.takeIf { it > 0.0 })
    }

    fun saveAndBroadcast(context: Context, service: String, values: Values) {
        if (values.fare == null && values.distance == null) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_PENDING_SERVICE, service)
            .putFloat(KEY_PENDING_FARE, (values.fare ?: 0.0).toFloat())
            .putFloat(KEY_PENDING_DISTANCE, (values.distance ?: 0.0).toFloat())
            .apply()
        context.sendBroadcast(Intent(ACTION_ORDER_CAPTURED).setPackage(context.packageName).apply {
            putExtra(EXTRA_SERVICE, service)
            values.fare?.let { putExtra(EXTRA_FARE, it) }
            values.distance?.let { putExtra(EXTRA_DISTANCE, it) }
        })
    }

    fun takePending(context: Context): Triple<String, Double?, Double?>? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val service = prefs.getString(KEY_PENDING_SERVICE, null) ?: return null
        val fare = prefs.getFloat(KEY_PENDING_FARE, 0f).takeIf { it > 0f }?.toDouble()
        val distance = prefs.getFloat(KEY_PENDING_DISTANCE, 0f).takeIf { it > 0f }?.toDouble()
        prefs.edit().remove(KEY_PENDING_SERVICE).remove(KEY_PENDING_FARE).remove(KEY_PENDING_DISTANCE).apply()
        return Triple(service, fare, distance)
    }

    fun serviceName(packageName: String): String = when (packageName.lowercase(java.util.Locale.ROOT)) {
        "ee.mtakso.driver" -> "Bolt"
        "ua.com.uklon.uklondriver" -> "Uklon"
        else -> ""
    }
}
