package ua.taximoney.taxiscan

import android.content.Context
import android.content.Intent

/** Parses only explicit fare and distance values, then keeps them on-device. */
object RideCapture {
    const val ACTION_ORDER_CAPTURED = "ua.taximoney.taxiscan.ORDER_CAPTURED"
    const val EXTRA_SERVICE = "service"
    const val EXTRA_FARE = "fare"
    const val EXTRA_DISTANCE = "distance"
    private const val PREFS = "taxiscan_settings"
    private const val KEY_PENDING_FARE = "captured_fare"
    private const val KEY_PENDING_DISTANCE = "captured_distance"
    private const val KEY_PENDING_SERVICE = "captured_service"

    data class Values(val fare: Double?, val distance: Double?)

    fun parse(text: String): Values {
        val normalized = text.replace('\u00a0', ' ').replace(',', '.')
        val fare = Regex("(?i)(?:(?:₴|грн|uah)\\s*([0-9]+(?:\\.[0-9]{1,2})?)|([0-9]+(?:\\.[0-9]{1,2})?)\\s*(?:грн|uah|₴))")
            .find(normalized)?.let { (it.groupValues[1].ifBlank { it.groupValues[2] }).toDoubleOrNull() }
        val distance = Regex("(?i)([0-9]+(?:\\.[0-9]{1,2})?)\\s*(?:км|km)(?![A-Za-z])")
            .find(normalized)?.groupValues?.get(1)?.toDoubleOrNull()
        return Values(fare?.takeIf { it > 0.0 }, distance?.takeIf { it > 0.0 })
    }

    fun saveAndBroadcast(context: Context, service: String, values: Values) {
        if (values.fare == null && values.distance == null) return
        if (!DriverPrefs.isMonitoringAllowed(context, service)) return
        if (DriverPrefs.prefs(context).getBoolean(DriverPrefs.LOGS_PAUSED, false)) return
        if (values.fare != null && values.distance != null &&
            !DriverPrefs.orderPassesFilter(context, values.fare, values.distance)) {
            appendLog(context, "$service • відхилено фільтром")
            return
        }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor
            .putString(KEY_PENDING_SERVICE, service)
            .putFloat(KEY_PENDING_FARE, (values.fare ?: 0.0).toFloat())
            .putFloat(KEY_PENDING_DISTANCE, (values.distance ?: 0.0).toFloat())
        if (values.fare != null && values.distance != null) {
            val serviceKey = service.lowercase(java.util.Locale.ROOT)
            val signature = "${values.fare}:${values.distance}"
            val lastSignatureKey = "stats_${serviceKey}_last_signature"
            val lastTimeKey = "stats_${serviceKey}_last_time"
            val now = System.currentTimeMillis()
            val duplicate = prefs.getString(lastSignatureKey, null) == signature &&
                now - prefs.getLong(lastTimeKey, 0L) < 120_000L
            if (!duplicate) {
                val totalKey = "stats_${serviceKey}_revenue"
                val tripsKey = "stats_${serviceKey}_trips"
                editor.putFloat(totalKey, prefs.getFloat(totalKey, 0f) + values.fare.toFloat())
                    .putInt(tripsKey, prefs.getInt(tripsKey, 0) + 1)
                    .putString(lastSignatureKey, signature)
                    .putLong(lastTimeKey, now)
            }
        }
        editor.apply()
        appendLog(context, "$service • ${values.fare ?: "—"} ₴ • ${values.distance ?: "—"} км")
        context.sendBroadcast(Intent(ACTION_ORDER_CAPTURED).setPackage(context.packageName).apply {
            putExtra(EXTRA_SERVICE, service)
            values.fare?.let { putExtra(EXTRA_FARE, it) }
            values.distance?.let { putExtra(EXTRA_DISTANCE, it) }
        })
    }

    private fun appendLog(context: Context, line: String) {
        val p = DriverPrefs.prefs(context)
        if (p.getBoolean(DriverPrefs.LOGS_PAUSED, false)) return
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val entries = (p.getString(DriverPrefs.LOG_LINES, "") ?: "").lineSequence().filter { it.isNotBlank() }.toMutableList()
        entries.add(0, "$stamp  $line")
        p.edit().putString(DriverPrefs.LOG_LINES, entries.take(50).joinToString("\n")).apply()
    }

    fun takePending(context: Context): Triple<String, Double?, Double?>? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val service = prefs.getString(KEY_PENDING_SERVICE, null) ?: return null
        val fare = prefs.getFloat(KEY_PENDING_FARE, 0f).takeIf { it > 0f }?.toDouble()
        val distance = prefs.getFloat(KEY_PENDING_DISTANCE, 0f).takeIf { it > 0f }?.toDouble()
        prefs.edit().remove(KEY_PENDING_SERVICE).remove(KEY_PENDING_FARE).remove(KEY_PENDING_DISTANCE).apply()
        return Triple(service, fare, distance)
    }

    fun serviceName(packageName: String): String = when (packageName.lowercase(java.util.Locale.ROOT)) {
        "ee.mtakso.driver" -> "Bolt"
        "ua.com.uklon.uklondriver" -> "Uklon"
        else -> ""
    }

    fun stats(context: Context, service: String): Pair<Double, Int> {
        val key = service.lowercase(java.util.Locale.ROOT)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getFloat("stats_${key}_revenue", 0f).toDouble() to
            prefs.getInt("stats_${key}_trips", 0)
    }
}
