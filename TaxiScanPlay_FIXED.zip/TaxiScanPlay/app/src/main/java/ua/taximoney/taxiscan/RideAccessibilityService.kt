package ua.taximoney.taxiscan

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RideAccessibilityService : AccessibilityService() {
    private var lastSignature = ""
    private var lastSentAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val packageName = event.packageName?.toString() ?: return
        val serviceName = RideCapture.serviceName(packageName)
        if (serviceName.isBlank()) return

        val text = buildString {
            event.text.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it).append(' ') }
            appendVisibleText(rootInActiveWindow, this, 0)
        }
        val values = RideCapture.parse(text)
        if (values.fare == null && values.distance == null) return

        val signature = "$serviceName:${values.fare}:${values.distance}"
        val now = System.currentTimeMillis()
        if (signature == lastSignature && now - lastSentAt < 5_000) return
        lastSignature = signature
        lastSentAt = now
        RideCapture.saveAndBroadcast(this, serviceName, values)
    }

    private fun appendVisibleText(node: AccessibilityNodeInfo?, target: StringBuilder, depth: Int) {
        if (node == null || depth > 18) return
        node.text?.let { target.append(it).append(' ') }
        node.contentDescription?.let { target.append(it).append(' ') }
        for (i in 0 until node.childCount.coerceAtMost(80)) {
            appendVisibleText(node.getChild(i), target, depth + 1)
        }
    }

    override fun onInterrupt() = Unit
}
