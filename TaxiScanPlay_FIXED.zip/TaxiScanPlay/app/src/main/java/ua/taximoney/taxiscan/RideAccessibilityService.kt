package ua.taximoney.taxiscan

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class RideAccessibilityService : AccessibilityService() {
    private var lastSignature = ""
    private var lastSentAt = 0L
    private var overlayView: TextView? = null
    private lateinit var windowManager: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val packageName = event.packageName?.toString() ?: return
        val serviceName = RideCapture.serviceName(packageName)
        if (serviceName.isBlank()) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) removeOverlay()
            return
        }
        if (!DriverPrefs.isMonitoringAllowed(this, serviceName)) { removeOverlay(); return }

        val text = buildString {
            event.text.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it).append(' ') }
            appendVisibleText(rootInActiveWindow, this, 0)
        }
        val values = RideCapture.parse(text)
        if (values.fare != null && values.distance != null) {
            if (DriverPrefs.orderPassesFilter(this, values.fare, values.distance)) showOverlay(serviceName, values.fare, values.distance)
            else removeOverlay()
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            removeOverlay()
        }
        if (values.fare == null && values.distance == null) return

        val signature = "$serviceName:${values.fare}:${values.distance}"
        val now = System.currentTimeMillis()
        if (signature == lastSignature && now - lastSentAt < 5_000) return
        lastSignature = signature
        lastSentAt = now
        val p = DriverPrefs.prefs(this)
        val statsKey = "stats_${serviceName.lowercase(Locale.ROOT)}_last_signature"
        val wasNew = values.fare != null && values.distance != null && p.getString(statsKey, null) != "${values.fare}:${values.distance}"
        RideCapture.saveAndBroadcast(this, serviceName, values)
        if (wasNew && p.getBoolean(DriverPrefs.SOUND_ENABLED, false)) {
            runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 75).startTone(ToneGenerator.TONE_PROP_BEEP, 180) }
        }
    }

    private fun appendVisibleText(node: AccessibilityNodeInfo?, target: StringBuilder, depth: Int) {
        if (node == null || depth > 18) return
        node.text?.let { target.append(it).append(' ') }
        node.contentDescription?.let { target.append(it).append(' ') }
        for (i in 0 until node.childCount.coerceAtMost(80)) {
            appendVisibleText(node.getChild(i), target, depth + 1)
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun showOverlay(service: String, fare: Double, distance: Double) {
        if (!Settings.canDrawOverlays(this)) return
        val prefs = DriverPrefs.prefs(this)
        val commissionRate = prefs.getFloat("commission_percent", 15f).toDouble()
        val costPerKm = prefs.getFloat("cost_per_km", 9f).toDouble()
        val commission = fare * commissionRate / 100.0
        val net = fare - commission - distance * costPerKm
        val format = NumberFormat.getNumberInstance(Locale.forLanguageTag("uk-UA")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        val text = "$service  •  ${format.format(fare)} ₴  •  ${format.format(distance)} км\n" +
            "Чистими: ${format.format(net)} ₴  (${format.format(net / distance)} ₴/км)"

        val color = runCatching { Color.parseColor(prefs.getString(DriverPrefs.OVERLAY_COLOR, "#32BB78")) }.getOrDefault(Color.rgb(50,187,120))
        val view = overlayView ?: TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.rgb(20, 28, 25))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), color)
            }
            elevation = dp(8).toFloat()
            overlayView = this
        }
        view.text = text
        view.textSize = prefs.getFloat(DriverPrefs.OVERLAY_TEXT_SIZE, 14f).coerceIn(10f, 28f)
        view.alpha = prefs.getFloat(DriverPrefs.OVERLAY_ALPHA, 1f).coerceIn(.2f, 1f)
        (view.background as? GradientDrawable)?.setStroke(dp(1), color)
        if (view.parent == null) {
            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(72)
                width = resources.displayMetrics.widthPixels - dp(24)
            }
            runCatching { windowManager.addView(view, params) }
                .onFailure { overlayView = null }
        } else {
            runCatching { windowManager.updateViewLayout(view, view.layoutParams) }
        }
    }

    private fun removeOverlay() {
        overlayView?.let { view -> runCatching { windowManager.removeView(view) } }
        overlayView = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
